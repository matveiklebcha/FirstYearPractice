﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
	public struct Ticket
	{
		public string typePlace;
		public decimal price;
	}
}
