﻿namespace ConsoleApp1
{
	internal class Program
	{
		const decimal CinemaFeeNecessary = 0.05m;
		const decimal TicketAmount = 0.05m;
		const decimal TicketAmountFromEight = 0.15m;
		const decimal CinemaCardLoyal = 0.10m;
		const decimal MaxDiscountLevel = 0.25m;

		public static readonly Dictionary<string, string> Messages = new Dictionary<string, string>
		{
			{ "EmptyType", "Тип места не может быть пустым!" },
			{ "InvalidPrice", "Цена должна быть положительным числом!" },
			{ "InvalidChoice", "Введите да или нет." }
		};
		public static readonly Dictionary<string, decimal> promoCodes = new Dictionary<string, decimal>
		{
			{ "STUDENT", 2m },
			{ "SCHOOL", 1.5m },
			{ "VIP", 3.0m }
		};
		public static readonly Dictionary<string, (decimal baseFee, decimal perTicketFee, bool hasFreeForMany)> hallSettings = new()
	   {
		{ "стандартный", (0m, 2m, true) },
		{ "vip", (5m, 3m, false) },
		{ "онлайн", (0m, 0m, false) }
	   };
		private static void Main(string[] args)
		{
			List<Ticket> tickets = CreateListTicket();
			Console.WriteLine("Выберите тип зала:\nСтандартный\nVIP\nОнлайн");
			string choiceHall = ReadLine();

			bool checkIsPremiere = ReadYesNo("Это премьерный показ? (да/нет)");
			
			bool hasCard = ReadYesNo("Есть ли у вас карта кинотеатра? (да/нет): ");

			string promoCode = "";
			if (ReadYesNo("Есть ли у вас промокод? (да/нет): "))
			{
				Console.Write("Введите промокод: ");
				promoCode = ReadLine();
			}

			decimal finalPrice = CalculateFinalPrice(tickets, hasCard, promoCode, choiceHall, checkIsPremiere);
			decimal percentage = CalculateTotalPercentage(tickets, hasCard);
			PrintTickets(finalPrice, percentage);
		}
		static bool ReadYesNo(string prompt)
		{
			while (true)
			{
				Console.Write(prompt);
				string input = ReadLine();
				if (input.ToLower() == "да")
				{
					return true;
				}
				if (input.ToLower() == "нет")
				{
					return false;
				}
				ShowError("InvalidChoice");
			}
		}
		static string ReadLine()
		{
			return Console.ReadLine()?.Trim() ?? "не указано";
		}
		static decimal CalculateFinalPrice(List<Ticket> tickets, bool hasCard, string promoCode, string choiceHall, bool isPremiere)
		{
			decimal total = PriceReservation(tickets);
			decimal percentage = CalculateTotalPercentage(tickets, hasCard);
			decimal priceAfterPercentDiscount = ApplyPercentageDiscount(total, percentage);
			if (CheckPromoCode(promoCode))
			{
				decimal discountPerTicket = promoCodes[promoCode.ToUpper()];
				priceAfterPercentDiscount = ApplyPromoCodeDiscount(tickets, discountPerTicket, priceAfterPercentDiscount);
				Console.WriteLine($"Применён промокод {promoCode}: скидка {discountPerTicket} у.е. за билет.");
			}
			decimal HallFee = CalculateHallFee(tickets, choiceHall);
			decimal cinemaFee = CalculateCinemaFee(priceAfterPercentDiscount, isPremiere);
			return priceAfterPercentDiscount + HallFee + cinemaFee;
		}
		static decimal CalculateHallFee(List<Ticket> tickets, string choiceHall)
		{
			decimal summHallFee = 0;
			if (hallSettings.ContainsKey(choiceHall.ToLower()))
			{
				var settings = hallSettings[choiceHall.ToLower()];
				summHallFee = settings.baseFee + (tickets.Count * settings.perTicketFee);

				if (settings.hasFreeForMany && tickets.Count > 6)
				{
					summHallFee = 0;
				}
			}
			return summHallFee;
		}
		static decimal CalculateCinemaFee(decimal priceAfterDiscount, bool isPremiere)
		{
			if(isPremiere)
			{
				decimal demandFactor = GenerateDemandFactor();
				return priceAfterDiscount * (demandFactor / 100);
			}
			return priceAfterDiscount * CinemaFeeNecessary;
		}
		static decimal GenerateDemandFactor()
		{
			Random random = new Random();
			return (decimal)random.Next(3,16);
		}
		static decimal GetQuantityDiscount(int ticketCount)
		{
			if (ticketCount >= 4 && ticketCount < 8)
			{
				return TicketAmount;
			}
			if (ticketCount >= 8)
			{
				return TicketAmountFromEight;
			}
			return 0;
		}
		static decimal GetCardDiscount(bool hasCard)
		{
			if (hasCard)
			{
				return CinemaCardLoyal;
			}
			return 0;
		}
		static decimal CalculateTotalPercentage(List<Ticket> tickets, bool hasCard)
		{
			decimal percentage = GetQuantityDiscount(tickets.Count) + GetCardDiscount(hasCard);
			if (percentage > 0.25m)
			{
				percentage = MaxDiscountLevel;
			}
			return percentage;
		}

		static decimal ApplyPercentageDiscount(decimal total, decimal percentage)
		{
			return total - (total * percentage);
		}

		static bool CheckPromoCode(string promocode)
		{
			if (promoCodes.ContainsKey(promocode.ToUpper()))
			{
				return true;
			}
			return false;
		}
		static decimal ApplyPromoCodeDiscount(List<Ticket> tickets, decimal discountPerTicket, decimal amountAfterPercent)
		{
			return amountAfterPercent - (discountPerTicket * tickets.Count);
		}

		static void ShowError(string key)
		{
			Console.WriteLine(Messages[key]);
		}
		static decimal ReadPositiveDecimal(string instruction)
		{
			while (true)
			{
				Console.Write(instruction);
				string input = ReadLine();
				if (decimal.TryParse(input, out decimal resultDecimal) && resultDecimal > 0)
				{
					return resultDecimal;
				}
				ShowError("InvalidPrice");
			}
		}
		static string ReadNonEmptyStr(string instruction)
		{
			while(true)
			{
				Console.Write(instruction);
				string input = ReadLine();
				if (!string.IsNullOrEmpty(input) && input != "не указано")
				{
					return input;
				}
				ShowError("EmptyType");
			}
		}
		static Ticket InputSingleTicket()
		{
			string typePlace = ReadNonEmptyStr("Введите тип места: ");
			decimal price = ReadPositiveDecimal("Введите цену билета: ");

			return new Ticket { typePlace = typePlace, price = price };
		}

		static List<Ticket> CreateListTicket()
		{
			List<Ticket> tickets = new List<Ticket>();

			while (true)
			{
				tickets.Add(InputSingleTicket());
				while (true)
				{
					Console.Write("\nХотите добавить еще один билет? (да/нет): ");
					string choice = ReadLine();
					if (choice.ToLower() == "да")
					{
						break;
					}
					if (choice.ToLower() == "нет")
					{
						return tickets;
					}
					ShowError("InvalidChoice");
				}
			}
		}
		static decimal PriceReservation(List<Ticket> tickets)
		{
			decimal summarizePrice = 0;
			foreach (Ticket item in tickets)
			{
				summarizePrice += item.price;
			}
			return summarizePrice;
		}

		static void PrintTickets(decimal finalPrice, decimal percentage)
		{
			Console.WriteLine($"Итоговая сумма: {finalPrice:F2}");
			if (percentage > 0)
			{
				Console.WriteLine($"Суммарная процентная скидка: {percentage * 100}%");
			}
			else
			{
				Console.WriteLine("Процентная скидка не применялась.");
			}
		}
	}
}