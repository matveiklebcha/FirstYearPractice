﻿// See https://aka.ms/new-console-template for more information
using System.Globalization;

namespace Gnas_stage_3
{
    internal class Program
    {
        private const string MoneyFormat = "0.00";
        private const decimal PercentScale = 100m;

        private const decimal MinimumBaseAfterDiscountFactor = 0.70m;

        private const decimal DistanceDiscountFromKmInclusive = 10m;
        private const decimal DistanceDiscountToKmExclusive = 30m;
        private const decimal DistanceDiscountPercentLow = 5m;
        private const decimal DistanceDiscountPercentHigh = 10m;

        private const decimal SubscriptionDiscountPercent = 7m;

        
        private const int TariffPickupToBuilding = 1;
        private const int TariffEconomRoute = 2;
        private const int TariffIdleTime = 3;

        private const decimal DoorPickupFixedFee = 50m;
        private const decimal DoorPickupFreeDistanceThresholdKm = 20m;

        private const decimal EconomRouteStartFeeCoefficient = 1m; 
        private const decimal EconomRouteAdditionalFeePerKm = 1.5m;

        private const decimal IdleFeePerMinute = 0.3m;

        
        private const decimal ServiceCommissionPercent = 15m;

        private const int AirportCommissionPercentMin = 10;  
        private const int AirportCommissionPercentMax = 25;  

       

        public static void Main(string[] args)
        {
            decimal distanceKm = ReadPositiveDecimal("Расстояние поездки (км): ");
            decimal ratePerKm = ReadPositiveDecimal("Базовый тариф за километр: ");
            decimal pickupFee = ReadPositiveDecimal("Стартовая плата за подачу: ");

            bool hasActiveSubscription = ReadSubscriptionFlag();

            ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue);

            bool isAirportTrip = ReadAirportFlag();

            int tariffChoice = ReadTariffChoice();
            decimal idleMinutes = 0m;
            if (tariffChoice == TariffIdleTime)
            {
                idleMinutes = ReadPositiveDecimal("Сколько минут простоя: ");
            }

            TaxiTrip trip = new TaxiTrip(distanceKm, ratePerKm, pickupFee);

            decimal totalPrice = CalculateTotalPrice(trip, hasActiveSubscription, hasPromoDiscount, promoIsPercent, promoValue, isAirportTrip, tariffChoice, idleMinutes);

            Console.WriteLine($"Итого: {totalPrice.ToString(MoneyFormat, CultureInfo.InvariantCulture)}");
        }

        private static decimal CalculateTotalPrice(TaxiTrip trip, bool hasActiveSubscription, bool hasPromoDiscount, bool promoIsPercent, decimal promoValue, bool isAirportTrip, int tariffChoice, decimal idleMinutes)
        {
            decimal baseAmountWithoutPickupFee = trip.DistanceKm * trip.RatePerKm;
            decimal minimumAllowedBase = baseAmountWithoutPickupFee * MinimumBaseAfterDiscountFactor;

            decimal currentBase = baseAmountWithoutPickupFee;

            currentBase = ApplyDistanceDiscount(currentBase, trip.DistanceKm);

            if (hasPromoDiscount)
            {
                currentBase = ApplyPromoDiscount(currentBase, promoIsPercent, promoValue);
            }

            if (hasActiveSubscription)
            {
                currentBase = ApplySubscriptionDiscount(currentBase);
            }

            
            if (currentBase < minimumAllowedBase)
            {
                currentBase = minimumAllowedBase;
            }

            decimal serviceCommission = CalculateServiceCommission(currentBase, isAirportTrip);

            decimal tariffFee = CalculateTariffFee(trip, tariffChoice);
            decimal idleFee = CalculateIdleFee(tariffChoice, idleMinutes);

           
            return currentBase + serviceCommission + tariffFee + idleFee;
        }

        private static decimal CalculateServiceCommission(decimal baseAmountAfterDiscounts, bool isAirportTrip)
        {
            if (!isAirportTrip)
            {
                return baseAmountAfterDiscounts * (ServiceCommissionPercent / PercentScale);
            }

            decimal airportCommissionPercent = GetRandomAirportCommissionPercent();
            return baseAmountAfterDiscounts * (airportCommissionPercent / PercentScale);
        }

        private static decimal GetRandomAirportCommissionPercent()
        {
            int percent = Random.Shared.Next(AirportCommissionPercentMin, AirportCommissionPercentMax + 1);
            return percent;
        }

        private static decimal CalculateTariffFee(TaxiTrip trip, int tariffChoice)
        {
            if (tariffChoice == TariffPickupToBuilding)
            {
                if (trip.DistanceKm > DoorPickupFreeDistanceThresholdKm)
                {
                    return 0m;
                }

                return DoorPickupFixedFee;
            }

            if (tariffChoice == TariffEconomRoute)
            {
              
                return trip.PickupFee * EconomRouteStartFeeCoefficient + EconomRouteAdditionalFeePerKm * trip.DistanceKm;
            }

            return 0m;
        }

        private static decimal CalculateIdleFee(int tariffChoice, decimal idleMinutes)
        {
            if (tariffChoice != TariffIdleTime)
            {
                return 0m;
            }

            return IdleFeePerMinute * idleMinutes;
        }

        private static decimal ApplyDistanceDiscount(decimal baseAmount, decimal distanceKm)
        {
            if (distanceKm < DistanceDiscountFromKmInclusive)
            {
                return baseAmount;
            }

            decimal discountPercent;

            if (distanceKm < DistanceDiscountToKmExclusive)
            {
                discountPercent = DistanceDiscountPercentLow; 
            }
            else
            {
                discountPercent = DistanceDiscountPercentHigh; 
            }

            decimal discountFraction = discountPercent / PercentScale;
            return baseAmount * (1m - discountFraction);
        }

        private static decimal ApplyPromoDiscount(decimal baseAmount, bool promoIsPercent, decimal promoValue)
        {
            if (!promoIsPercent)
            {
                if (baseAmount == 0m)
                {
                    return 0m;
                }

                
                decimal effectiveDiscountFraction = promoValue / baseAmount;
                decimal discounted = baseAmount * (1m - effectiveDiscountFraction);

                return discounted < 0m ? 0m : discounted;
            }

            decimal discountFraction = promoValue / PercentScale;
            return baseAmount * (1m - discountFraction);
        }

        private static decimal ApplySubscriptionDiscount(decimal baseAmount)
        {
            decimal discountFraction = SubscriptionDiscountPercent / PercentScale;
            return baseAmount * (1m - discountFraction);
        }

        private static bool ReadSubscriptionFlag()
        {
            while (true)
            {
                Console.Write("Активная подписка? (yes/no): ");
                string? input = Console.ReadLine();

                if (input == null)
                {
                    Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
                    continue;
                }

                string normalized = input.Trim().ToLowerInvariant();

                if (normalized == "y" || normalized == "yes" || normalized == "да")
                {
                    return true;
                }

                if (normalized == "n" || normalized == "no" || normalized == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
            }
        }

        private static bool ReadAirportFlag()
        {
            while (true)
            {
                Console.Write("Поездка в аэропорт? (yes/no): ");
                string? input = Console.ReadLine();

                if (input == null)
                {
                    Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
                    continue;
                }

                string normalized = input.Trim().ToLowerInvariant();

                if (normalized == "y" || normalized == "yes" || normalized == "да")
                {
                    return true;
                }

                if (normalized == "n" || normalized == "no" || normalized == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
            }
        }

        private static int ReadTariffChoice()
        {
            while (true)
            {
                Console.WriteLine("Выберите тариф:");
                Console.WriteLine("1 - Подача к подъезду (50; бесплатно если расстояние > 20 км)");
                Console.WriteLine("2 - Эконом-маршрут (стартовая плата + 1.5 у.е./км)");
                Console.WriteLine("3 - Расчёт по простою (0.3 у.е. за минуту простоя)");
                Console.Write("Ваш выбор (1/2/3): ");

                string? input = Console.ReadLine();
                if (input == null)
                {
                    Console.WriteLine("Ошибка: введите 1, 2 или 3.");
                    continue;
                }

                string normalized = input.Trim();

                if (int.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out int tariff) && (tariff == TariffPickupToBuilding || tariff == TariffEconomRoute || tariff == TariffIdleTime))
                {
                    return tariff;
                }

                Console.WriteLine("Ошибка: введите 1, 2 или 3.");
            }
        }

        private static void ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue)
        {
            hasPromoDiscount = false;
            promoIsPercent = false;
            promoValue = 0m;

            while (true)
            {
                Console.Write("Промокод (пусто = нет скидки). Пример: 10% (процент) или 50 (фикс): ");
                string? input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    return;
                }

                string normalized = input.Trim().Replace(',', '.');

                if (normalized.EndsWith("%"))
                {
                    string numberPart = normalized[..^1].Trim();

                    if (TryParseDecimal(numberPart, out decimal percent) && percent > 0m && percent <= 100m)
                    {
                        hasPromoDiscount = true;
                        promoIsPercent = true;
                        promoValue = percent;
                        return;
                    }

                    Console.WriteLine("Ошибка: процент должен быть числом от 1 до 100.");
                    continue;
                }

                if (TryParseDecimal(normalized, out decimal fixedAmount) && fixedAmount > 0m)
                {
                    hasPromoDiscount = true;
                    promoIsPercent = false;
                    promoValue = fixedAmount;
                    return;
                }

                Console.WriteLine("Ошибка: фиксированная скидка должна быть числом больше 0.");
            }
        }

        private static decimal ReadPositiveDecimal(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out decimal value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: введите число больше 0.");
            }
        }

        private static bool TryParsePositiveDecimal(string? input, out decimal value)
        {
            value = 0m;

            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }

            string normalized = input.Trim().Replace(',', '.');

            bool success = decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
            return success && value > 0m;
        }

        private static bool TryParseDecimal(string input, out decimal value)
        {
            return decimal.TryParse(input, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
        }
    }
}
