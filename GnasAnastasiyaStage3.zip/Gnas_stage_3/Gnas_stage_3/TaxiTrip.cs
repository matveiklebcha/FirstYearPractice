﻿
namespace Gnas_stage_3
{
    internal struct TaxiTrip
    {
        public decimal DistanceKm { get; }
        public decimal RatePerKm { get; }
        public decimal PickupFee { get; }

        public TaxiTrip(decimal distanceKm, decimal ratePerKm, decimal pickupFee)
        {
            DistanceKm = distanceKm;
            RatePerKm = ratePerKm;
            PickupFee = pickupFee;
        }
    }
}