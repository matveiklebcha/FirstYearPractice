﻿using System.Globalization;
struct Policy
{
    public double CarPrice;
    public double Rate;
    public int DriverAge;
    public int DrivingExperience;
    public bool HasFamilyBenefit;
    public int SelectedOption;
    public int ExtraDriversCount;
    public bool IsHighRiskRegion;
    public int CarYear;
    public int CurrentYear;
}

class Program
{
    const double surcharge = 1.10;
    const int age_limit = 25;
    const double experience_discount_low = 0.05;
    const double experience_discount_high = 0.15;
    const int experience_low = 3;
    const int experience_high = 10;
    const double family_discount = 0.10;
    const double max_discount = 0.20;
    const double max_discount_adult = 0.35;
    const double regional_coeff = 1.1;
    const double min_risk_coeff = 1.2;
    const double max_risk_coeff = 1.6;
    const double car1_discount = 5.0;
    const double add_driver_price = 2.0;
    const int experience_limit = 15;
    const int glass_casco_lite = 15;
    const int koeff_casco_lite = 1;
    const string promo_file = "promo.txt";
    const string clients_file = "clients.txt";

    static void Main(string[] args)
    {
        Policy policy = new Policy();

        double promo = 0;

        Console.Write("ID клиента (или Enter если нет): ");
        string clientId = Console.ReadLine().Trim();

        if (!string.IsNullOrEmpty(clientId))
        {
            if (!ReadClientData(clientId, out policy.CarPrice))
            {
                Console.WriteLine("Ошибка: клиент не найден.");
                return;
            }
            Console.WriteLine($"Стоимость автомобиля: {policy.CarPrice}");

            Console.Write("Промокод (или Enter если нет): ");
            string inputPromo = Console.ReadLine().Trim();
            if (!string.IsNullOrEmpty(inputPromo))
                promo = GetPromoDiscount(clientId, inputPromo);
        }
        else
        {
            Console.Write("Стоимость автомобиля: ");
            while (!TryReadDouble(out policy.CarPrice))
            {
                Console.WriteLine("Ошибка: введите число больше 0.");
                Console.Write("Стоимость автомобиля: ");
            }
        }

        Console.Write("Базовая ставка (например 0.04): ");
        while (!TryReadDouble(out policy.Rate))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Базовая ставка (например 0.04): ");
        }

        Console.Write("Возраст водителя: ");
        while (!TryReadInt(out policy.DriverAge) || policy.DriverAge <= 0)
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Возраст водителя: ");
        }

        Console.Write("Безаварийный стаж (лет): ");
        while (!TryReadInt(out policy.DrivingExperience) || policy.DrivingExperience > policy.DriverAge)
        {
            Console.WriteLine($"Ошибка: стаж не может превышать возраст ({policy.DriverAge} лет).");
            Console.Write("Безаварийный стаж (лет): ");
        }

        Console.Write("Льготная категория (да/нет): ");
        policy.HasFamilyBenefit = Console.ReadLine().Trim().ToLower() == "да";

        Console.Write("Регион повышенного риска (да/нет): ");
        policy.IsHighRiskRegion = Console.ReadLine().Trim().ToLower() == "да";

        Console.Write("Год выпуска автомобиля: ");
        while (!TryReadInt(out policy.CarYear) || policy.CarYear < 1900 || policy.CarYear > 2026)
        {
            Console.WriteLine("Ошибка: введите год от 1900 до 2026.");
            Console.Write("Год выпуска автомобиля: ");
        }

        policy.CurrentYear = DateTime.Now.Year;
        Console.Write($"Текущий год: {policy.CurrentYear} ");

        Console.WriteLine("\nВыберите дополнительную опцию:");
        Console.WriteLine("1 - Скидка за единственный автомобиль (-5 у.е.)");
        Console.WriteLine("2 - Дополнительный водитель (+2 у.е. за каждого)");
        Console.WriteLine("3 - Без дополнительных опций");
        Console.WriteLine("4 - Расширенное покрытие (стёкла/каско-лайт)");
        while (true)
        {
            Console.Write("Выберите опцию (1-4): ");
            if (!TryReadInt(out policy.SelectedOption) || policy.SelectedOption < 1 || policy.SelectedOption > 4)
    {
                Console.WriteLine("Ошибка: введите число от 1 до 4.");
                continue;
            }

            switch (policy.SelectedOption)
            {
                case 1:
                    if (policy.DrivingExperience > experience_limit)
                    {
                        Console.WriteLine($"Опция недоступна: стаж превышает {experience_limit} лет. Выбрана опция 3.");
                        policy.SelectedOption = 3;
                    }
                    break;

                case 2:
                    Console.Write("Количество дополнительных водителей: ");
                    while (!TryReadInt(out policy.ExtraDriversCount) || policy.ExtraDriversCount <= 0)
                    {
                        Console.WriteLine("Ошибка: введите число больше 0.");
                        Console.Write("Количество дополнительных водителей: ");
                    }
                    break;

                case 3:
                    break;

                case 4:
                    if (policy.CarPrice <= 300)
                    {
                        Console.WriteLine("Опция недоступна: стоимость меньше 300 у.е. Выбрана опция 3.");
                        policy.SelectedOption = 3;
                    }
                    break;
            }

            break;
        }

        double cost = Calculate(policy, promo / 100.0);
        PrintResult(cost);
    }

    static bool TryReadDouble(out double value)
    {
        string normalized = Console.ReadLine().Trim().Replace(',', '.');
        return double.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value) && value > 0;
    }

    static bool TryReadInt(out int value)
    {
        return int.TryParse(Console.ReadLine().Trim(), out value) && value >= 0;
    }

    static double GetExperienceDiscount(int experience)
    {
        if (experience >= experience_low && experience < experience_high)
            return experience_discount_low;
        if (experience >= experience_high)
            return experience_discount_high;
        return 0;
    }

    static double GetFamilyDiscount(bool hasFamilyBenefit)
    {
        if (hasFamilyBenefit) return family_discount;
        return 0;
    }

    static double GetBestBaseDiscount(Policy policy) 
    {
        return Math.Max(GetExperienceDiscount(policy.DrivingExperience), GetFamilyDiscount(policy.HasFamilyBenefit));
    }

    static double ApplyDiscountLimit(double discount, int driverAge)
    {
        double limit = driverAge < age_limit ? max_discount : max_discount_adult;
        return discount > limit ? limit : discount;
    }

    static double GetRegionalCoeff(bool isHighRisk)
    {
        if (!isHighRisk) return regional_coeff;
        return new Random().NextDouble() * (max_risk_coeff - min_risk_coeff) + min_risk_coeff;
    }

    static double GetOptionCost(Policy policy)
    {
        switch (policy.SelectedOption)
        {
            case 1: return policy.DrivingExperience <= experience_limit ? -car1_discount : 0;
            case 2: return add_driver_price * policy.ExtraDriversCount;
            case 4: return glass_casco_lite + koeff_casco_lite * (policy.CurrentYear - policy.CarYear);
            default: return 0;
        }
    }

    static bool ReadClientData(string clientId, out double carPrice)
    {
        carPrice = 0;
        if (!File.Exists(clients_file))
        {
            Console.WriteLine("Файл клиентов не найден.");
            return false;
        }

        string[] lines = File.ReadAllLines(clients_file);
        foreach (string line in lines)
        {
            string[] parts = line.Split(',');
            if (parts.Length < 5) continue;
            if (!string.Equals(parts[0].Trim(), clientId, StringComparison.OrdinalIgnoreCase)) continue;

            double.TryParse(parts[4].Trim().Replace(',', '.'),
                NumberStyles.Number, CultureInfo.InvariantCulture, out carPrice);
            return true;
        }

        Console.WriteLine($"Клиент '{clientId}' не найден.");
        return false;
    }

    static bool ClientUsedPromo(string clientId)
    {
        if (!File.Exists(clients_file))
        {
            Console.WriteLine("Файл клиентов не найден.");
            return true;
        }

        string[] lines = File.ReadAllLines(clients_file);
        foreach (string line in lines)
        {
            string[] parts = line.Split(',');
            if (parts.Length < 4) continue;
            if (!string.Equals(parts[0].Trim(), clientId, StringComparison.OrdinalIgnoreCase)) continue;

            return parts[2].Trim().ToLower() == "да";
        }

        Console.WriteLine($"Клиент '{clientId}' не найден.");
        return true;
    }

    static void MarkClientUsedPromo(string clientId, string promoName)
    {
        if (!File.Exists(clients_file)) return;

        string[] lines = File.ReadAllLines(clients_file);
        for (int i = 0; i < lines.Length; i++)
        {
            string[] parts = lines[i].Split(',');
            if (parts.Length < 4) continue;
            if (!string.Equals(parts[0].Trim(), clientId, StringComparison.OrdinalIgnoreCase)) continue;

            parts[2] = "да";
            parts[3] = promoName;
            lines[i] = string.Join(",", parts);
            File.WriteAllLines(clients_file, lines);
            return;
        }
    }

    static double GetPromoDiscount(string clientId, string promoName)
    {
        if (ClientUsedPromo(clientId))
        {
            Console.WriteLine($"Клиент '{clientId}' уже использовал промокод.");
            return 0;
        }

        if (!File.Exists(promo_file))
        {
            Console.WriteLine("Файл промокодов не найден.");
            return 0;
        }

        try
        {
            string[] lines = File.ReadAllLines(promo_file);
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts.Length < 2) continue;

                string filePromo = parts[0].Trim();
                string fileDiscount = parts[1].Trim().Replace(',', '.');

                if (!string.Equals(filePromo, promoName, StringComparison.OrdinalIgnoreCase)) continue;

                if (parts.Length == 3)
                {
                    if (!string.Equals(parts[2].Trim(), clientId, StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine($"Промокод '{promoName}' не предназначен для клиента '{clientId}'.");
                        return 0;
                    }
                }

                if (double.TryParse(fileDiscount, NumberStyles.Number, CultureInfo.InvariantCulture, out double discount) && discount >= 0)
                {
                    Console.WriteLine($"Промокод '{filePromo}' применён! Скидка: {discount}%");
                    MarkClientUsedPromo(clientId, promoName);
                    return discount;
                }
            }
            Console.WriteLine($"Промокод '{promoName}' не найден.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        return 0;
    }

    static double Calculate(Policy policy, double promoDiscount)
    {
        double cost = policy.CarPrice * policy.Rate;
        double totalDiscount = ApplyDiscountLimit(GetBestBaseDiscount(policy), policy.DriverAge) + promoDiscount;
        cost *= (1 - totalDiscount);
        cost = policy.DriverAge < age_limit ? cost * surcharge : cost;
        cost *= GetRegionalCoeff(policy.IsHighRiskRegion);
        cost += GetOptionCost(policy);
        return cost < 0 ? 0 : cost;
    }

    static void PrintResult(double cost)
    {
        Console.WriteLine("Итого: " + cost.ToString("F2", CultureInfo.InvariantCulture));
    }

}
