﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace PracticeProject
{
    class Program
    {
        // Константы для скидок
        private const double DiscountRate_5Percent = 0.05;
        private const double DiscountRate_12Percent = 0.12;
        private const double DiscountThreshold_Low = 50.0;
        private const double DiscountThreshold_High = 150.0;
        private const double MaxDiscountInMoney = 20.0;

        // Константы для валидации
        private const int MinCount = 1;
        private const double MinPrice = 0.01;

        // Уровни лояльности
        private const int LoyaltyNone = 0;
        private const int LoyaltyBronze = 3;
        private const int LoyaltySilver = 5;
        private const int LoyaltyGold = 8;

        struct Dish
        {
            public string Name;
            public double Price;
            public int Count;
        }

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости заказа в сервисе доставки еды\n");

            // Ввод данных
            int dishCount = ReadPositiveInteger("Сколько блюд вы хотите заказать? ");
            List<Dish> order = InputOrder(dishCount);

            // Ввод промокода (опционально)
            Console.Write("\nВведите промокод (или оставьте пустым): ");
            string promoCode = Console.ReadLine()?.Trim() ?? "";

            // Выбор уровня лояльности
            int loyaltyPercent = SelectLoyaltyLevel();

            // Расчёт
            double subtotal = CalculateSubtotal(order);
            double discountAmount = CalculateTotalDiscount(subtotal, loyaltyPercent, promoCode);
            double total = subtotal - discountAmount;

            // Вывод результатов
            Console.WriteLine($"\nСумма заказа без скидок: {subtotal:F2} у.е.");
            Console.WriteLine($"Скидка: {discountAmount:F2} у.е.");
            Console.WriteLine($"Итого: {total:F2} у.е.");

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static List<Dish> InputOrder(int count)
        {
            List<Dish> order = [];

            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"\nБлюдо #{i + 1}:");
                Dish dish = new()
                {
                    Name = ReadNonEmptyString("  Название: "),
                    Price = ReadPositiveDouble("  Цена: "),
                    Count = ReadPositiveInteger("  Количество: ")
                };

                order.Add(dish);
            }

            return order;
        }

        static int SelectLoyaltyLevel()
        {
            Console.WriteLine("\nВыберите уровень программы лояльности:");
            Console.WriteLine($"  0 - Нет уровня (0%)");
            Console.WriteLine($"  1 - Bronze ({LoyaltyBronze}%)");
            Console.WriteLine($"  2 - Silver ({LoyaltySilver}%)");
            Console.WriteLine($"  3 - Gold ({LoyaltyGold}%)");

            while (true)
            {
                int choice = ReadPositiveInteger("Ваш выбор (0-3): ", 0);

                if (choice >= 0 && choice <= 3)
                {
                    return choice switch
                    {
                        1 => LoyaltyBronze,
                        2 => LoyaltySilver,
                        3 => LoyaltyGold,
                        0 => LoyaltyNone,
                        _ => LoyaltyNone,
                    };
                }

                Console.WriteLine("Ошибка: Выберите число от 0 до 3.");
            }
        }

        static double CalculateSubtotal(List<Dish> order)
        {
            double subtotal = 0;

            foreach (Dish dish in order)
            {
                subtotal += dish.Price * dish.Count;
            }

            return subtotal;
        }

        static double CalculateTotalDiscount(double subtotal, int loyaltyPercent, string promoCode)
        {
            double discountPercent = CalculateOrderSumDiscount(subtotal);

            discountPercent += loyaltyPercent / 100.0;

            CalculatePromoDiscount(promoCode, out double promoDiscountPercent, out double promoDiscountInMoney);
            discountPercent += promoDiscountPercent;

            double discountInMoney = subtotal * discountPercent + promoDiscountInMoney;

            if (discountInMoney > MaxDiscountInMoney)
            {
                discountInMoney = MaxDiscountInMoney;
            }

            return discountInMoney;
        }

        static double CalculateOrderSumDiscount(double subtotal)
        {
            if (subtotal >= DiscountThreshold_High)
            {
                return DiscountRate_12Percent;
            }
            else if (subtotal >= DiscountThreshold_Low && subtotal < DiscountThreshold_High)
            {
                return DiscountRate_5Percent;
            }

            return 0;
        }

        static void CalculatePromoDiscount(string promoCode, out double percentDiscount, out double fixedDiscount)
        {
            percentDiscount = 0;
            fixedDiscount = 0;

            if (string.IsNullOrWhiteSpace(promoCode))
                return;

            switch (promoCode.ToUpper())
            {
                case "DISCOUNT10":
                    percentDiscount = 0.10;
                    break;

                case "FIXED5":
                    fixedDiscount = 5.0;
                    break;

                case "WELCOME":
                    percentDiscount = 0.15;
                    break;

                case "NEWYEAR":
                    fixedDiscount = 10.0;
                    break;

                default:
                    Console.WriteLine($"Промокод '{promoCode}' не найден.");
                    break;
            }
        }

        static string ReadNonEmptyString(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine()?.Trim() ?? "";

                if (!string.IsNullOrWhiteSpace(input))
                {
                    return input;
                }

                Console.WriteLine("Ошибка: Название не может быть пустым.");
            }
        }

        static int ReadPositiveInteger(string message, int min = 1)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine() ?? "";

                if (int.TryParse(input, out int value) && value >= min)
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите целое число от {MinCount} и выше.");
            }
        }

        static double ReadPositiveDouble(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine() ?? "";

                if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out double value) && value >= MinPrice)
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите число больше {MinPrice:F2} (например, 150.50).");
            }
        }
    }
}