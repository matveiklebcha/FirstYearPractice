﻿using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
namespace ConsoleApp1;

internal class Program
{
	const decimal CinemaFeeNecessary = 0.05m;
	const decimal TicketAmount = 0.05m;
	const decimal TicketAmountFromEight = 0.15m;
	const decimal CinemaCardLoyal = 0.10m;
	const decimal MaxDiscountLevel = 0.25m;
	const string path = "UsersData.json";
	static List<UserUsedPromoCode> usedPromoCodes = new List<UserUsedPromoCode>();

	private static readonly JsonSerializerOptions JsonOptions = new()
	{
		WriteIndented = true,
		Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
		IncludeFields = true
	};
	public static readonly Dictionary<string, string> Messages = new Dictionary<string, string>
		{
			{ "InvalidPrice", "Цена должна быть положительным числом!" },
			{ "InvalidChoice", "Введите да или нет." },
			{ "EmptyStr", "строка не должны быть пустой"},
			{ "4d-зал", "4D-зал доступен только при бронировании более 2 билетов." }
		};
	public static readonly Dictionary<string, decimal> promoCodes = new Dictionary<string, decimal>
		{
			{ "STUDENT", 2m },
			{ "SCHOOL", 1.5m },
			{ "VIP", 3.0m }
		};
	public static readonly Dictionary<string, (decimal baseFee, decimal perTicketFee, bool hasFreeForMany)> hallSettings = new()
	   {
		{ "стандартный", (0m, 2m, true) },
		{ "vip", (5m, 3m, false) },
		{ "онлайн", (0m, 0m, false) },
		{ "4d-зал", (5m,2m,false) }
	   };
	private static void Main(string[] args)
	{
		usedPromoCodes = LoadUsedPromoCodesFromFile();
		string studentName = ReadNonEmptyStr("Введите ваше ФИО: ");
		List<Ticket> tickets = CreateListTicket();
		string choiceHall = InPutChoiceHall(tickets.Count);

		bool checkIsPremiere = ReadYesNo("Это премьерный показ? (да/нет)");

		bool hasCard = ReadYesNo("Есть ли у вас карта кинотеатра? (да/нет): ");

		string promoCode = InPutPromoCode(studentName);

		decimal finalPrice = CalculateFinalPrice(tickets, hasCard, promoCode, choiceHall, checkIsPremiere);
		decimal percentage = CalculateTotalPercentage(tickets, hasCard);
		PrintTickets(finalPrice, percentage);
		SaveToFileUserData(usedPromoCodes);
	}
	static string InPutChoiceHall(int count)
	{
		string choiceHall;
		while (true)
		{
			Console.WriteLine("Выберите тип зала:\nСтандартный\nVIP\nОнлайн\n4d-зал");
			choiceHall = ReadLine();
			if (choiceHall.ToLower() == "4d-зал" && count <= 2)
			{
				Console.WriteLine(Messages["4d-зал"]);
				continue;
			}
			break;
		}
		return choiceHall;
	}
	static string InPutPromoCode(string studentName)
	{
		if (!ReadYesNo("Есть ли у вас промокод? (да/нет): "))
		{
			return "";
		}

		string promo = ReadNonEmptyStr("Введите промокод: ");

		if (!CheckPromoCode(promo))
		{
			Console.WriteLine($"Неверный промокод. Ваш ввод: {promo}");
			return "";
		}

		if (CheckUserPromoCode(usedPromoCodes, studentName, promo))
		{
			Console.WriteLine($"Вы уже использовали этот промокод ({promo}).");
			return "";
		}

		usedPromoCodes.Add(new UserUsedPromoCode { StudentName = studentName, PromoCode = promo.ToUpper() });
		Console.WriteLine($"Промокод {promo} применён.");
		return promo;
	}
	static bool ReadYesNo(string prompt)
	{
		while (true)
		{
			Console.Write(prompt);
			string input = ReadLine();
			if (input.ToLower() == "да")
			{
				return true;
			}
			if (input.ToLower() == "нет")
			{
				return false;
			}
			Console.WriteLine(Messages["InvalidChoice"]);
		}
	}
	static string ReadLine()
	{
		return Console.ReadLine()?.Trim() ?? "не указано";
	}
	static decimal CalculateFinalPrice(List<Ticket> tickets, bool hasCard, string promoCode, string choiceHall, bool isPremiere)
	{
		decimal total = tickets.Sum(x => x.price);
		decimal quantityDiscount = GetQuantityDiscount(tickets.Count);
		decimal cardDiscount = hasCard ? CinemaCardLoyal : 0;
		decimal percentage = Math.Max(quantityDiscount, cardDiscount);
		decimal priceAfterPercentDiscount = total - (total * percentage);
		if (CheckPromoCode(promoCode))
		{
			decimal discountPerTicket = promoCodes[promoCode.ToUpper()];
			priceAfterPercentDiscount = ApplyPromoCodeDiscount(tickets, discountPerTicket, priceAfterPercentDiscount);
			Console.WriteLine($"Применён промокод {promoCode}: скидка {discountPerTicket} у.е. за билет.");
		}
		decimal HallFee = CalculateHallFee(tickets, choiceHall);
		decimal cinemaFee = CalculateCinemaFee(priceAfterPercentDiscount, isPremiere);
		return priceAfterPercentDiscount + HallFee + cinemaFee;
	}
	static decimal CalculateHallFee(List<Ticket> tickets, string choiceHall)
	{
		decimal summHallFee = 0;
		if (hallSettings.ContainsKey(choiceHall.ToLower()))
		{
			var settings = hallSettings[choiceHall.ToLower()];
			summHallFee = settings.baseFee + (tickets.Count * settings.perTicketFee);

			if (settings.hasFreeForMany && tickets.Count > 6)
			{
				summHallFee = 0;
			}
		}
		return summHallFee;
	}
	static decimal CalculateCinemaFee(decimal priceAfterDiscount, bool isPremiere)
	{
		if (isPremiere)
		{
			decimal demandFactor = GenerateDemandFactor();
			return priceAfterDiscount * (demandFactor / 100);
		}
		return priceAfterDiscount * CinemaFeeNecessary;
	}
	static decimal GenerateDemandFactor()
	{
		Random random = new Random();
		return (decimal)random.Next(3, 16);
	}
	static decimal GetQuantityDiscount(int ticketCount)
	{
		if (ticketCount >= 4 && ticketCount < 8)
		{
			return TicketAmount;
		}
		if (ticketCount >= 8)
		{
			return TicketAmountFromEight;
		}
		return 0;
	}
	static decimal GetCardDiscount(bool hasCard)
	{
		if (hasCard)
		{
			return CinemaCardLoyal;
		}
		return 0;
	}
	static decimal CalculateTotalPercentage(List<Ticket> tickets, bool hasCard)
	{
		decimal percentage = Math.Max(GetQuantityDiscount(tickets.Count), GetCardDiscount(hasCard));
		if (percentage > MaxDiscountLevel)
		{
			percentage = MaxDiscountLevel;
		}
		return percentage;
	}
	static bool CheckPromoCode(string promocode)
	{
		return promoCodes.ContainsKey(promocode.ToUpper());
	}
	static bool CheckUserPromoCode(List<UserUsedPromoCode> users, string userName, string promocode)
	{
		return users.Exists(user => user.StudentName == userName && user.PromoCode.ToUpper() == promocode.ToUpper());
	}
	static decimal ApplyPromoCodeDiscount(List<Ticket> tickets, decimal discountPerTicket, decimal amountAfterPercent)
	{
		return amountAfterPercent - (discountPerTicket * tickets.Count);
	}
	static List<UserUsedPromoCode> LoadUsedPromoCodesFromFile()
	{
		string path = "UsersData.json";
		if (!File.Exists(path))
		{
			return new List<UserUsedPromoCode>();
		}
		string json = File.ReadAllText(path);
		return JsonSerializer.Deserialize<List<UserUsedPromoCode>>(json, JsonOptions) ?? new List<UserUsedPromoCode>();
	}
	static decimal ReadPositiveDecimal(string instruction)
	{
		while (true)
		{
			Console.Write(instruction);
			string input = ReadLine();
			if (decimal.TryParse(input, out decimal resultDecimal) && resultDecimal > 0)
			{
				return resultDecimal;
			}
			Console.WriteLine(Messages["InvalidPrice"]);
		}
	}
	static string ReadNonEmptyStr(string instruction)
	{
		while (true)
		{
			Console.Write(instruction);
			string input = ReadLine();
			if (!string.IsNullOrEmpty(input) && input != "не указано")
			{
				return input;
			}
			Console.WriteLine(Messages["EmptyStr"]);
		}
	}
	static Ticket InputSingleTicket()
	{
		string typePlace = ReadNonEmptyStr("Введите тип места: ");
		decimal price = ReadPositiveDecimal("Введите цену билета: ");

		return new Ticket { typePlace = typePlace, price = price };
	}

	static List<Ticket> CreateListTicket()
	{
		List<Ticket> tickets = new List<Ticket>();

		while (true)
		{
			tickets.Add(InputSingleTicket());
			while (true)
			{
				Console.Write("\nХотите добавить еще один билет? (да/нет): ");
				string choice = ReadLine();
				if (choice.ToLower() == "да")
				{
					break;
				}
				if (choice.ToLower() == "нет")
				{
					return tickets;
				}
				Console.WriteLine(Messages["InvalidChoice"]);
			}
		}
	}
	static void SaveToFileUserData(List<UserUsedPromoCode> users)
	{
		string json = JsonSerializer.Serialize(users, JsonOptions);
		File.WriteAllText(path, json, Encoding.UTF8);
	}
	static void PrintTickets(decimal finalPrice, decimal percentage)
	{
		Console.WriteLine($"Итоговая сумма: {finalPrice:F2}");
		if (percentage > 0)
		{
			Console.WriteLine($"Суммарная процентная скидка: {percentage * 100}%");
		}
		else
		{
			Console.WriteLine("Процентная скидка не применялась.");
		}
	}
}