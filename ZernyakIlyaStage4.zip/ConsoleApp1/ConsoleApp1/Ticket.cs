﻿

namespace ConsoleApp1;

public struct Ticket
{
	public string typePlace;
	public decimal price;
}
