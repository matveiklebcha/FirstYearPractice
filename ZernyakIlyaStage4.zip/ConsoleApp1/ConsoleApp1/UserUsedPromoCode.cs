﻿

namespace ConsoleApp1;

public struct UserUsedPromoCode
{
	public string StudentName;
	public string PromoCode;
}