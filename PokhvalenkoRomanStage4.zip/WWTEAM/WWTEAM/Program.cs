﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MembershipPriceCalculator
{
    public static class PricingConstants
    {
        public const double DiscountRateThreeToTwelveMonths = 0.05;
        public const double DiscountRateTwelveMonthsAndMore = 0.15;
        public const int DiscountThresholdMonthsLower = 3;
        public const int DiscountThresholdMonthsUpper = 12;
        public const double StudentDiscountRate = 0.10;
        public const double MaxTotalPercentageDiscount = 0.30;
        public const double StandardServiceFeePerMonth = 3.0;
        public const int StandardServiceFreeThresholdMonths = 6;
        public const double PersonalTrainerBaseFee = 10.0;
        public const double PersonalTrainerPerSessionFee = 5.0;
        public const double PremiumZoneBaseFee = 10.0;
        public const double PremiumZonePerVisitFee = 2.0;
        public const double MedicalFeeRate = 0.05;
        public const double MedicalFeeMinRate = 0.01;
        public const double MedicalFeeMaxRate = 0.15;
        public const int ServiceTypeStandard = 1;
        public const int ServiceTypePersonalTrainer = 2;
        public const int ServiceTypeSelfStudy = 3;
        public const int ServiceTypePremiumZone = 4;
        public const string ReferralCodesFilePath = "referral_codes.txt";
    }

    public static class ReferralCodeManager
    {
        private static HashSet<string> usedCodes = new HashSet<string>();
        private static Dictionary<string, double> availableCodes = new Dictionary<string, double>();

        static ReferralCodeManager()
        {
            LoadReferralCodes();
        }

        private static void LoadReferralCodes()
        {
            try
            {
                if (File.Exists(PricingConstants.ReferralCodesFilePath))
                {
                    string[] lines = File.ReadAllLines(PricingConstants.ReferralCodesFilePath);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length == 2 && double.TryParse(parts[1].Trim(), out double discount))
                        {
                            string code = parts[0].Trim();
                            if (!string.IsNullOrEmpty(code))
                            {
                                availableCodes[code] = discount;
                            }
                        }
                    }
                    Console.WriteLine($"Загружено {availableCodes.Count} реферальных кодов из файла.");
                }
                else
                {
                    Console.WriteLine($"Файл {PricingConstants.ReferralCodesFilePath} не найден. ");
                    
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке реферальных кодов: {ex.Message}");
                availableCodes = new Dictionary<string, double>();
            }
        }

        

        public static bool TryUseReferralCode(string code, out double discount)
        {
            discount = 0;

            if (string.IsNullOrWhiteSpace(code))
            {
                return false;
            }

            string normalizedCode = code.Trim().ToUpper();

            if (usedCodes.Contains(normalizedCode))
            {
                Console.WriteLine($"Код '{code}' уже был использован.");
                return false;
            }

            if (availableCodes.TryGetValue(normalizedCode, out double discountValue))
            {
                usedCodes.Add(normalizedCode);
                discount = discountValue;
                SaveUsedCodes(); 
                return true;
            }

            Console.WriteLine($"Код '{code}' не найден.");
            return false;
        }

        private static void SaveUsedCodes()
        {
            try
            {
                string usedCodesPath = "used_referral_codes.txt";
                File.WriteAllLines(usedCodesPath, usedCodes);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Не удалось сохранить список использованных кодов: {ex.Message}");
            }
        }

        public static int GetAvailableCodesCount()
        {
            return availableCodes.Count - usedCodes.Count;
        }

        public static bool IsCodeAvailable(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return false;

            string normalizedCode = code.Trim().ToUpper();
            return availableCodes.ContainsKey(normalizedCode) && !usedCodes.Contains(normalizedCode);
        }
    }

    class Program
    {
        static void Main()
        {
            Console.WriteLine("Расчёт стоимости абонемента в фитнес-клуб\n");
            Console.WriteLine($"Доступно {ReferralCodeManager.GetAvailableCodesCount()} реферальных кодов.\n");

            int membershipMonths = ReadPositiveInteger("Введите срок абонемента в месяцах: ");
            double pricePerMonth = ReadPositiveDecimal("Введите стоимость за месяц: ");

            string referralCode = ReadReferralCode("Введите реферальный код (или оставьте пустым): ");
            double referralDiscount = 0;
            bool isReferralCodeUsed = false;

            if (!string.IsNullOrWhiteSpace(referralCode))
            {
                if (ReferralCodeManager.TryUseReferralCode(referralCode, out referralDiscount))
                {
                    isReferralCodeUsed = true;
                    Console.WriteLine($"Код успешно активирован! Скидка: {referralDiscount:F2} руб.");
                }
                else
                {
                    Console.WriteLine("Не удалось применить реферальный код.");
                }
            }

            bool isStudent = ReadStudentStatus("Есть ли у вас студенческий статус? (да/нет): ");
            bool isProfessionalAthlete = ReadProfessionalAthleteStatus("Являетесь ли вы профессиональным спортсменом? (да/нет): ");

            Console.WriteLine("\nВыберите дополнительную услугу:");
            Console.WriteLine($"1 - Стандартное обслуживание");
            Console.WriteLine($"2 - Персональный тренер");
            Console.WriteLine($"3 - Самостоятельные занятия");
            Console.WriteLine($"4 - Премиум-зона (бассейн и спа)");
            int serviceType = ReadServiceType("Введите номер услуги (1-4): ");

            int trainerSessions = 0;
            if (serviceType == PricingConstants.ServiceTypePersonalTrainer)
            {
                trainerSessions = ReadPositiveIntegerOrZero("Введите количество запланированных занятий с тренером: ");
            }

            int premiumVisits = 0;
            if (serviceType == PricingConstants.ServiceTypePremiumZone)
            {
                premiumVisits = ReadPositiveIntegerOrZero("Введите количество посещений премиум-зоны: ");
            }

            double totalPrice = CalculateMembershipPrice(
                membershipMonths,
                pricePerMonth,
                referralDiscount,
                isStudent,
                isProfessionalAthlete,
                serviceType,
                trainerSessions,
                premiumVisits,
                isReferralCodeUsed);

            Console.WriteLine($"\nИтого: {totalPrice:F2} руб.");
            Console.WriteLine($"\nДоступно реферальных кодов: {ReferralCodeManager.GetAvailableCodesCount()}");
        }

        static string ReadReferralCode(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine()?.Trim();
        }
        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveInteger(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите целое положительное число.");
            }
        }

        static int ReadPositiveIntegerOrZero(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveIntegerOrZero(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите целое неотрицательное число.");
            }
        }

        static double ReadPositiveDecimal(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }

        static bool ReadStudentStatus(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да")
                {
                    return true;
                }

                if (input == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static bool ReadProfessionalAthleteStatus(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да")
                {
                    return true;
                }

                if (input == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static int ReadServiceType(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParseServiceType(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите число от 1 до 4.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveIntegerOrZero(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue >= 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveDecimal(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParseServiceType(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue >= 1 && parsedValue <= 4)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static double CalculateMembershipPrice(
            int months,
            double pricePerMonth,
            double referralDiscount,
            bool isStudent,
            bool isProfessionalAthlete,
            int serviceType,
            int trainerSessions,
            int premiumVisits,
            bool isReferralCodeUsed)
        {
            double basePrice = months * pricePerMonth;

            double percentageDiscountRate = CalculatePercentageDiscountRate(months, isStudent);
            double priceAfterPercentageDiscount = basePrice * (1 - percentageDiscountRate);

            double priceAfterReferral = ApplyReferralDiscount(
                priceAfterPercentageDiscount,
                pricePerMonth,
                referralDiscount,
                months,
                isReferralCodeUsed);

            double medicalFee = CalculateMedicalFee(priceAfterReferral, isProfessionalAthlete);
            double additionalServiceFee = CalculateAdditionalServiceFee(months, serviceType, trainerSessions, premiumVisits);

            return priceAfterReferral + medicalFee + additionalServiceFee;
        }

        static double CalculatePercentageDiscountRate(int months, bool isStudent)
        {
            double durationDiscount = 0;

            if (months >= PricingConstants.DiscountThresholdMonthsLower &&
                months < PricingConstants.DiscountThresholdMonthsUpper)
            {
                durationDiscount = PricingConstants.DiscountRateThreeToTwelveMonths;
            }
            else if (months >= PricingConstants.DiscountThresholdMonthsUpper)
            {
                durationDiscount = PricingConstants.DiscountRateTwelveMonthsAndMore;
            }

            double studentDiscount = isStudent ? PricingConstants.StudentDiscountRate : 0;

            double maxDiscount = Math.Max(durationDiscount, studentDiscount);

            return Math.Min(maxDiscount, PricingConstants.MaxTotalPercentageDiscount);
        }

        static double ApplyReferralDiscount(
            double priceAfterPercentageDiscount,
            double pricePerMonth,
            double referralDiscount,
            int months,
            bool isReferralCodeUsed)
        {
            if (!isReferralCodeUsed || months < 1 || referralDiscount <= 0)
            {
                return priceAfterPercentageDiscount;
            }

            double firstMonthPrice = pricePerMonth;
            double discountedFirstMonthPrice = Math.Max(0, firstMonthPrice - referralDiscount);
            return priceAfterPercentageDiscount - (firstMonthPrice - discountedFirstMonthPrice);
        }

        static double CalculateAdditionalServiceFee(int months, int serviceType, int trainerSessions, int premiumVisits)
        {
            switch (serviceType)
            {
                case PricingConstants.ServiceTypeStandard:
                    return CalculateStandardServiceFee(months);
                case PricingConstants.ServiceTypePersonalTrainer:
                    return CalculatePersonalTrainerFee(trainerSessions);
                case PricingConstants.ServiceTypeSelfStudy:
                    return 0;
                case PricingConstants.ServiceTypePremiumZone:
                    return CalculatePremiumZoneFee(months, premiumVisits);
                default:
                    return 0;
            }
        }

        static double CalculateStandardServiceFee(int months)
        {
            if (months >= PricingConstants.StandardServiceFreeThresholdMonths)
            {
                return 0;
            }

            return months * PricingConstants.StandardServiceFeePerMonth;
        }

        static double CalculatePersonalTrainerFee(int trainerSessions)
        {
            return PricingConstants.PersonalTrainerBaseFee +
                   (trainerSessions * PricingConstants.PersonalTrainerPerSessionFee);
        }

        static double CalculatePremiumZoneFee(int months, int premiumVisits)
        {
            if (months <= 1)
            {
                Console.WriteLine("Внимание: Премиум-зона доступна только при сроке абонемента более 1 месяца.");
                return 0;
            }

            return PricingConstants.PremiumZoneBaseFee +
                   (premiumVisits * PricingConstants.PremiumZonePerVisitFee);
        }

        static double CalculateMedicalFee(double priceAfterDiscounts, bool isProfessionalAthlete)
        {
            if (isProfessionalAthlete)
            {
                Random random = new Random();
                double medicalCertificateValidity = random.NextDouble();
                double adjustedRate = PricingConstants.MedicalFeeMinRate +
                                     (PricingConstants.MedicalFeeMaxRate - PricingConstants.MedicalFeeMinRate) *
                                     (1 - medicalCertificateValidity);

                Console.WriteLine($"\n Результат проверки медицинской справки: {medicalCertificateValidity:F2} ({medicalCertificateValidity * 100:F0}%)");
                Console.WriteLine($" Ставка медицинского сбора: {adjustedRate:P2}");

                return priceAfterDiscounts * adjustedRate;
            }
            else
            {
                return priceAfterDiscounts * PricingConstants.MedicalFeeRate;
            }
        }
    }
}