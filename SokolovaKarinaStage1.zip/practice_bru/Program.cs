﻿
using System.Globalization;

struct Policy
{
    public double CarPrice;
    public double Rate;
    public int DriverAge;
    public double Cost;
}

class Program
{
    const double surcharge = 1.10;
    const int age_limit = 25;
    static void Main(string[] args)
    {
        Policy policy = new Policy();

        Console.Write("Стоимость автомобиля: ");
        while (!TryReadDouble(out policy.CarPrice))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Стоимость автомобиля: ");
        }

        Console.Write("Базовая ставка (например 0.04): ");
        while (!TryReadDouble(out policy.Rate))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Базовая ставка (например 0.04): ");
        }

        Console.Write("Возраст водителя: ");
        while (!TryReadInt(out policy.DriverAge))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Возраст водителя: ");
        }

        double cost = Calculate(policy);
        PrintResult(cost);
    }

    static bool TryReadDouble(out double value)
    {
        string normalized = Console.ReadLine().Trim().Replace(',', '.');
        return double.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value) && value > 0;
    }

    static bool TryReadInt(out int value)
    {
        return int.TryParse(Console.ReadLine().Trim(), out value) && value > 0;
    }

    static double Calculate(Policy policy)
    {
        double cost = policy.CarPrice * policy.Rate;
        if (policy.DriverAge < age_limit)
        {
            cost *= surcharge;
        }
        return cost;
    }

    static void PrintResult(double cost)
    {
       Console.WriteLine("Итого: " + cost);
    }

}
