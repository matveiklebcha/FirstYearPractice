namespace ConsoleApp4;

internal static class IndependentDiscountCalculator
{
    public static double CalculateTotalAmount(
        int rentalDays,
        double dailyRate,
        int previousRentalCount,
        double corporatePromoDiscountRate)
    {
        double baseAmount = rentalDays * dailyRate;

        double durationDiscountRate = RentalDurationDiscount.GetDiscountRate(rentalDays);
        double regularRenterDiscountRate = RegularRenterDiscount.GetDiscountRate(previousRentalCount);

        return baseAmount
            * (1 - durationDiscountRate)
            * (1 - corporatePromoDiscountRate)
            * (1 - regularRenterDiscountRate);
    }
}
