﻿namespace ConsoleApp4;

using System.Globalization;
using System.IO;

internal static class Program
{
    private const int DiscountDayThreshold = 7;
    private const double DiscountRate = 0.05;

    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        try
        {
            Run();
        }
        catch (Exception exception)
        {
            Console.WriteLine();
            Console.WriteLine($"Ошибка программы: {exception.Message}");
            Console.WriteLine("Нажмите Enter для выхода.");
            Console.ReadLine();
        }
    }

    private static void Run()
    {
        while (true)
        {
            SafeClearConsole();
            Console.WriteLine();
            Console.WriteLine("========== МЕНЮ ==========");
            Console.WriteLine("1 - Посчитать стоимость аренды авто");
            Console.WriteLine("2 - Выход");
            ShowPrompt(PromptType.MenuChoice);

            string? menuChoice = Console.ReadLine()?.Trim();

            if (menuChoice is null)
            {
                return;
            }

            if (menuChoice.Length == 0)
            {
                continue;
            }

            switch (menuChoice)
            {
                case "1":
                    CalculateAndShowRentalCostWithIndependentDiscounts();
                    break;
                case "2":
                    Console.WriteLine("Программа завершена.");
                    return;
                default:
                    ShowError(ErrorType.InvalidMenuChoice);
                    break;
            }
        }
    }

 

    private static void CalculateAndShowRentalCostWithIndependentDiscounts()
    {
        Console.WriteLine();
        Console.WriteLine("--- Расчёт стоимости аренды ---");

        int rentalDays = ReadPositiveInteger();
        double dailyRate = ReadPositiveNumber();
        int previousRentalCount = ReadNonNegativeInteger();

        ShowPrompt(PromptType.CorporatePromoCode);
        string promoCode = Console.ReadLine() ?? string.Empty;
        double corporatePromoDiscountRate = CorporatePromoCodeProvider.GetDiscountRateByCode(promoCode);

        double totalAmount = IndependentDiscountCalculator.CalculateTotalAmount(
            rentalDays,
            dailyRate,
            previousRentalCount,
            corporatePromoDiscountRate);

        Console.WriteLine();
        Console.WriteLine($"Итого: {totalAmount}");
        WaitForKeyPress();
    }

    private static int ReadPositiveInteger()
    {
        int rentalDays;
        while (true)
        {
            ShowPrompt(PromptType.RentalDays);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveInteger(input, out rentalDays))
            {
                break;
            }

            ShowError(ErrorType.InvalidInteger);
        }

        return rentalDays;
    }

    private static double ReadPositiveNumber()
    {
        double dailyRate;
        while (true)
        {
            ShowPrompt(PromptType.DailyRate);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveNumber(input, out dailyRate))
            {
                break;
            }

            ShowError(ErrorType.InvalidNumber);
        }

        return dailyRate;
    }

    private static int ReadNonNegativeInteger()
    {
        int previousRentalCount;
        while (true)
        {
            ShowPrompt(PromptType.PreviousRentalCount);

            string input = Console.ReadLine() ?? "0";
            if (TryParseNonNegativeInteger(input, out previousRentalCount))
            {
                break;
            }

            ShowError(ErrorType.InvalidNonNegativeInteger);
        }

        return previousRentalCount;
    }

    private static bool TryParsePositiveInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value > 0;
    }

    private static bool TryParseNonNegativeInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value >= 0;
    }

    private static bool TryParsePositiveNumber(string input, out double value)
    {
        string normalizedInput = input.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedInput, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            return false;
        }

        return value > 0;
    }

    private static void SafeClearConsole()
    {
        try
        {
            Console.Clear();
        }
        catch (IOException)
        {
        }
    }

    private static void WaitForKeyPress()
    {
        Console.WriteLine();
        Console.WriteLine("Нажмите Enter, чтобы вернуться в меню.");
        Console.ReadLine();
    }

    private static void ShowPrompt(PromptType promptType)
    {
        string prompt = promptType switch
        {
            PromptType.MenuChoice => "Введите номер пункта: ",
            PromptType.RentalDays => "Введите количество дней аренды: ",
            PromptType.DailyRate => "Введите стоимость аренды за 1 день: ",
            PromptType.PreviousRentalCount => "Введите количество прошлых аренд клиента: ",
            PromptType.CorporatePromoCode => "Введите корпоративный промокод (или Enter, если нет): ",
            _ => string.Empty,
        };

        Console.Write(prompt);
    }

    private static void ShowError(ErrorType errorType)
    {
        string message = errorType switch
        {
            ErrorType.InvalidMenuChoice => "Нет такого пункта меню!",
            ErrorType.InvalidInteger => "Ошибка! Нужно ввести целое число больше 0",
            ErrorType.InvalidNumber => "Ошибка! Нужно ввести число больше 0",
            ErrorType.InvalidNonNegativeInteger => "Ошибка! Нужно ввести целое число 0 или больше",
            _ => "Неизвестная ошибка",
        };

        Console.WriteLine(message);
    }

    private enum PromptType
    {
        MenuChoice,
        RentalDays,
        DailyRate,
        PreviousRentalCount,
        CorporatePromoCode,
    }

    private enum ErrorType
    {
        InvalidMenuChoice,
        InvalidInteger,
        InvalidNumber,
        InvalidNonNegativeInteger,
    }

    private static double CalculateTotalAmount(int rentalDays, double dailyRate)
    {
        if (rentalDays <= DiscountDayThreshold)
        {
            return rentalDays * dailyRate;
        }

        return rentalDays * dailyRate * (1 - DiscountRate);
    }
}
