namespace ConsoleApp4;

internal static class CorporatePromoCodeProvider
{
    private static readonly string PromoCodesFilePath = Path.Combine(
        AppContext.BaseDirectory,
        "corporate_promo_codes.txt");

    public static double GetDiscountRateByCode(string promoCode)
    {
        if (string.IsNullOrWhiteSpace(promoCode))
        {
            return 0;
        }

        if (!File.Exists(PromoCodesFilePath))
        {
            return 0;
        }

        foreach (string line in File.ReadAllLines(PromoCodesFilePath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith('#'))
            {
                continue;
            }

            string[] parts = line.Split('=', 2, StringSplitOptions.TrimEntries);
            if (parts.Length != 2)
            {
                continue;
            }

            if (!parts[0].Equals(promoCode, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (!double.TryParse(parts[1], out double percent) || percent < 0)
            {
                return 0;
            }

            return percent / 100;
        }

        return 0;
    }
}
