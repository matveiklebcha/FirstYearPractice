﻿using System;
using System.Collections.Generic;

namespace intership_LOL_XD
{
    internal class Program
    {
        private const double DiscountRate = 0.05;
        private const int DiscountThresholdTickets = 3;

        public struct Ticket(string category, double price)
        {
            public string Category { get; set; } = category;
            public double Price { get; set; } = price;
        }

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости билетов на концерт\n");
            int ticketCount = ReadPositiveInteger("Введите количество билетов: ");
            List<Ticket> tickets = ReadTickets(ticketCount);

            double baseSum = CalculateBaseSum(tickets);
            double finalSum = CalculateTotalPrice(baseSum, tickets.Count);

            Console.WriteLine($"\nИтого: {finalSum:F2}");
        }
        static List<Ticket> ReadTickets(int count)
        {
            List<Ticket> tickets = new List<Ticket>(count);
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"\nБилет #{i + 1}:");
                Ticket ticket = ReadTicket();
                tickets.Add(ticket);
            }
            return tickets;
        }
        static Ticket ReadTicket()
        {
            string category = ReadNonEmptyString("Введите категорию места (портер, танцпол и т.д.): ");
            double price = ReadPositiveDouble("Введите цену билета: ");
            return new Ticket(category, price);
        }
        static string ReadNonEmptyString(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(input))
                    return input;
                Console.WriteLine("Ошибка: Категория не может быть пустой.");
            }
        }
        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveInteger(input, out int value))
                    return value;
                Console.WriteLine("Ошибка: Введите положительное целое число.");
            }
        }
        static double ReadPositiveDouble(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveDouble(input, out double value))
                    return value;
                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }
        static bool TryParsePositiveInteger(string? input, out int value)
        {
            value = 0;
            if (int.TryParse(input, out int parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }
        static bool TryParsePositiveDouble(string input, out double value)
        {
            value = 0;
            if (double.TryParse(input, out double parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }
        static double CalculateBaseSum(List<Ticket> tickets)
        {
            double sum = 0;
            foreach (var ticket in tickets)
                sum += ticket.Price;
            return sum;
        }
        static double CalculateTotalPrice(double basePrice, int ticketCount)
        {
            if (ticketCount >= DiscountThresholdTickets)
                return basePrice * (1 - DiscountRate);
            return basePrice;
        }
    }
}