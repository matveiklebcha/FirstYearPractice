﻿
using System.Globalization;

struct Policy
{
    public double CarPrice;
    public double Rate;
    public int DriverAge;
    public int DrivingExperience;
    public bool HasFamilyBenefit;
    public int SelectedOption;       
    public int ExtraDriversCount;   
    public bool IsHighRiskRegion;   
}

class Program
{
    const double surcharge = 1.10;
    const int age_limit = 25;
    const double experience_discount_low = 0.05;
    const double experience_discount_high = 0.15;
    const int experience_low = 3;
    const int experience_high = 10;
    const double family_discount = 0.10;
    const double max_discount = 0.20;
    const double max_discount_adult = 0.35;

    const double regional_coeff = 1.1;
    const double car1_discount = 5.0;
    const double base_price = 0.0;
    const double add_driver_price = 2.0;
    const int experience_limit = 15;

    static void Main(string[] args)
    {
        Policy policy = new Policy();

        Console.Write("Стоимость автомобиля: ");
        while (!TryReadDouble(out policy.CarPrice))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Стоимость автомобиля: ");
        }

        Console.Write("Базовая ставка (например 0.04): ");
        while (!TryReadDouble(out policy.Rate))
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Базовая ставка (например 0.04): ");
        }

        Console.Write("Возраст водителя: ");
        while (!TryReadInt(out policy.DriverAge) || policy.DriverAge <= 0)
        {
            Console.WriteLine("Ошибка: введите число больше 0.");
            Console.Write("Возраст водителя: ");
        }

        Console.Write("Безаварийный стаж : ");
        while (!TryReadInt(out policy.DrivingExperience) || policy.DrivingExperience > policy.DriverAge)
        {
            Console.WriteLine($"Ошибка: стаж не может превышать возраст водителя ({policy.DriverAge} лет).");
            Console.Write("Безаварийный стаж : ");
        }

        Console.Write("Введите название промокода (или нажмите Enter, если нет): ");
        string inputPromo = Console.ReadLine().Trim();
        double promo = 0;

        if (!string.IsNullOrEmpty(inputPromo))
        {
            promo = GetPromoDiscountFromFile("promo.txt", inputPromo);
        }

        Console.Write("Льготная категория (да/нет): ");
        policy.HasFamilyBenefit = Console.ReadLine().Trim().ToLower() == "да";


        Console.Write("Регион повышенного риска (да/нет): ");
        policy.IsHighRiskRegion = Console.ReadLine().Trim().ToLower() == "да";

        Console.WriteLine("\nВыберите дополнительную опцию полиса:");
        Console.WriteLine("1. Скидка за единственный автомобиль в семье (-5 у.е.)");
        Console.WriteLine("2. Дополнительный водитель в полисе (+2 у.е. за каждого)");
        Console.WriteLine("3. Без дополнительных опций");

        while (true)
        {
            Console.Write("Введите номер опции (1-3): ");
            if (TryReadInt(out policy.SelectedOption))
            {
                bool optionValid = true;

                if (policy.SelectedOption == 1)
                {
                    if (policy.DrivingExperience > experience_limit)
                    {
                        Console.WriteLine($"Ваш стаж превышает {experience_limit} лет. Скидка не применима.");
                        optionValid = false;
                    }
                }

                else if(policy.SelectedOption == 2)
                {
                    Console.Write("Количество дополнительных водителей: ");
                    while (!TryReadInt(out policy.ExtraDriversCount))
                    {
                        Console.WriteLine("Ошибка : введите число от 0 и больше.");
                        Console.Write("Количество дополнительных водителей: ");
                    }
                }

                else if (policy.SelectedOption == 3)
                {

                }
                else
                {
                    Console.WriteLine("Ошибка: выберите число от 1 до 3.");
                    optionValid = false;
                }

                if (optionValid) break;

            }

            else
            {
                Console.WriteLine("Ошибка: введите корректное число.");
            }
        }

        double cost = Calculate(policy, promo / 100.0);
        PrintResult(cost);
    }

    static double GetPromoDiscountFromFile(string fileName, string promoName)
    {
        if (!File.Exists(fileName))
        {
            try
            {
                File.WriteAllLines(fileName, new string[] { "SUMMER20=20", "BROKER15=15", "START5=5" });
                Console.WriteLine($"[Инфо]: Файл {fileName} не найден. Создан шаблон файла с кодами SUMMER20, BROKER15, START5.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Ошибка создания файла]: {ex.Message}");
                return 0;
            }
        }

        try
        {
            string[] lines = File.ReadAllLines(fileName);
            foreach (string line in lines)
            {
                string[] parts = line.Split('=');
                if (parts.Length == 2)
                {
                    string currentKey = parts[0].Trim();
                    string currentValue = parts[1].Trim().Replace(',', '.');

                    if (string.Equals(currentKey, promoName, StringComparison.OrdinalIgnoreCase))
                    {
                        if (double.TryParse(currentValue, NumberStyles.Number, CultureInfo.InvariantCulture, out double discount) && discount >= 0)
                        {
                            Console.WriteLine($"[Успех]: Промокод '{currentKey}' найден! Скидка: {discount}%");
                            return discount;
                        }
                    }
                }
            }
            Console.WriteLine($"[Предупреждение]: Промокод '{promoName}' не найден в базе данных. Скидка: 0%");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Ошибка чтения файла]: {ex.Message}. Скидка: 0%");
        }

        return 0;
    }

    static bool TryReadDouble(out double value)
    {
        string normalized = Console.ReadLine().Trim().Replace(',', '.');
        return double.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value) && value > 0;
    }

    static bool TryReadInt(out int value)
    {
        return int.TryParse(Console.ReadLine().Trim(), out value) && value >= 0;
    }

    static double GetExperienceDiscount(int experience)
    {
        if (experience >= experience_low && experience < experience_high)
            return experience_discount_low;
        if (experience >= experience_high)
            return experience_discount_high;
        return 0;
    }

    static double GetFamilyDiscount(bool hasFamilyBenefit)
    {
        return hasFamilyBenefit ? family_discount : 0;
    }

    static double GetTotalDiscount(Policy policy, double promoDiscount)
    {
        return GetExperienceDiscount(policy.DrivingExperience)
             + promoDiscount
             + GetFamilyDiscount(policy.HasFamilyBenefit);
    }

    static double ApplyDiscountLimit(double totalDiscount, int driverAge)
    {
        double currentMaxDiscount = driverAge < age_limit ? max_discount : max_discount_adult;
        return totalDiscount > currentMaxDiscount ? currentMaxDiscount : totalDiscount;
    }

    static double Calculate(Policy policy, double promoDiscount)
    {
        double cost = policy.CarPrice * policy.Rate;
        cost *= (1 - ApplyDiscountLimit(GetTotalDiscount(policy, promoDiscount), policy.DriverAge));
        if (policy.DriverAge < age_limit)
            cost *= surcharge;

        double regionalCoefficient = regional_coeff;
        if (policy.IsHighRiskRegion)
        {
            Random rand = new Random();
            regionalCoefficient = rand.NextDouble() * (1.6 - 1.2) + 1.2;
        }

        cost *= regionalCoefficient;

        if (policy.SelectedOption == 1)
        {
            if (policy.DrivingExperience <= experience_limit)
            {
                cost -= car1_discount;
            }

        }

        else if (policy.SelectedOption == 2)
        {
            double optionsPrice = base_price + (policy.ExtraDriversCount * add_driver_price);
            cost += optionsPrice;
        }

        return cost < 0 ? 0 : cost;
    }

    static void PrintResult(double cost)
    {
        Console.WriteLine("Итого: " + cost.ToString("F2", CultureInfo.InvariantCulture));
    }
}