﻿namespace ConsoleApp4;

using System.Globalization;
using System.IO;

internal static class Program
{
    private const int DiscountDayThreshold = 7;
    private const double DiscountRate = 0.05;

    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        try
        {
            Run();
        }
        catch (Exception exception)
        {
            Console.WriteLine();
            Console.WriteLine($"Ошибка программы: {exception.Message}");
            Console.WriteLine("Нажмите Enter для выхода.");
            Console.ReadLine();
        }
    }

    private static void Run()
    {
        while (true)
        {
            SafeClearConsole();
            Console.WriteLine();
            Console.WriteLine("1 - Посчитать стоимость аренды авто");
            Console.WriteLine("2 - Выход");
            ShowPrompt(PromptType.MenuChoice);

            string? menuChoice = Console.ReadLine()?.Trim();

            if (menuChoice is null)
            {
                return;
            }

            if (menuChoice.Length == 0)
            {
                continue;
            }

            switch (menuChoice)
            {
                case "1":
                    CalculateAndShowRentalCostWithIndependentDiscounts();
                    break;
                case "2":
                    Console.WriteLine("Программа завершена.");
                    return;
                default:
                    ShowError(ErrorType.InvalidMenuChoice);
                    break;
            }
        }
    }

 

    private static void CalculateAndShowRentalCostWithIndependentDiscounts()
    {
        Console.WriteLine();
        Console.WriteLine("--- Расчёт стоимости аренды ---");

        int rentalDays = ReadPositiveInteger();
        double dailyRate = ReadPositiveNumber();
        int previousRentalCount = ReadNonNegativeInteger();

        ShowPrompt(PromptType.CorporatePromoCode);
        string promoCode = Console.ReadLine() ?? string.Empty;
        double corporatePromoDiscountRate = CorporatePromoCodeProvider.GetDiscountRateByCode(promoCode);

        double totalAmount = IndependentDiscountCalculator.CalculateTotalAmount(
            rentalDays,
            dailyRate,
            previousRentalCount,
            corporatePromoDiscountRate);

        Console.WriteLine();
        Console.WriteLine($"Сумма после скидок: {totalAmount}");

        double finalTotal = RunStageThree(rentalDays, totalAmount);
        Console.WriteLine();
        Console.WriteLine($"Итого: {finalTotal}");
        Console.ReadKey();
    }

    private static int ReadPositiveInteger()
    {
        int rentalDays;
        while (true)
        {
            ShowPrompt(PromptType.RentalDays);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveInteger(input, out rentalDays))
            {
                break;
            }

            ShowError(ErrorType.InvalidInteger);
        }

        return rentalDays;
    }

    private static double ReadPositiveNumber()
    {
        double dailyRate;
        while (true)
        {
            ShowPrompt(PromptType.DailyRate);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveNumber(input, out dailyRate))
            {
                break;
            }

            ShowError(ErrorType.InvalidNumber);
        }

        return dailyRate;
    }

    private static int ReadNonNegativeInteger()
    {
        int previousRentalCount;
        while (true)
        {
            ShowPrompt(PromptType.PreviousRentalCount);

            string input = Console.ReadLine() ?? "0";
            if (TryParseNonNegativeInteger(input, out previousRentalCount))
            {
                break;
            }

            ShowError(ErrorType.InvalidNonNegativeInteger);
        }

        return previousRentalCount;
    }

    private static bool TryParsePositiveInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value > 0;
    }

    private static bool TryParseNonNegativeInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value >= 0;
    }

    private static bool TryParsePositiveNumber(string input, out double value)
    {
        string normalizedInput = input.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedInput, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            return false;
        }

        return value > 0;
    }

    private static void SafeClearConsole()
    {
        try
        {
            Console.Clear();
        }
        catch (IOException)
        {
        }
    }



    private static void ShowPrompt(PromptType promptType)
    {
        string prompt = promptType switch
        {
            PromptType.MenuChoice => "Введите номер пункта: ",
            PromptType.RentalDays => "Введите количество дней аренды: ",
            PromptType.DailyRate => "Введите стоимость аренды за 1 день: ",
            PromptType.PreviousRentalCount => "Введите количество прошлых аренд клиента: ",
            PromptType.CorporatePromoCode => "Введите корпоративный промокод (или Enter, если нет): ",
            PromptType.DeliveryMethod => "Введите номер варианта: ",
            PromptType.DistanceKilometers => "Введите расстояние от офиса в километрах: ",
            PromptType.IsPremiumCar => "Автомобиль премиум-класса? (1 - да, 0 - нет): ",
            _ => string.Empty,
        };

        Console.Write(prompt);
    }

    private static void ShowError(ErrorType errorType)
    {
        string message = errorType switch
        {
            ErrorType.InvalidMenuChoice => "Нет такого пункта меню!",
            ErrorType.InvalidInteger => "Ошибка! Нужно ввести целое число больше 0",
            ErrorType.InvalidNumber => "Ошибка! Нужно ввести число больше 0",
            ErrorType.InvalidNonNegativeInteger => "Ошибка! Нужно ввести целое число 0 или больше",
            ErrorType.InvalidDeliveryMethod => "Ошибка! Нужно ввести 1, 2 или 3",
            ErrorType.InvalidDistance => "Ошибка! Нужно ввести число 0 или больше",
            ErrorType.InvalidPremiumChoice => "Ошибка! Нужно ввести 1 или 0",
            _ => "Неизвестная ошибка",
        };

        Console.WriteLine(message);
    }

    private enum PromptType
    {
        MenuChoice,
        RentalDays,
        DailyRate,
        PreviousRentalCount,
        CorporatePromoCode,
        DeliveryMethod,
        DistanceKilometers,
        IsPremiumCar,
    }

    private enum ErrorType
    {
        InvalidMenuChoice,
        InvalidInteger,
        InvalidNumber,
        InvalidNonNegativeInteger,
        InvalidDeliveryMethod,
        InvalidDistance,
        InvalidPremiumChoice,
    }

    private enum DeliveryMethod
    {
        City = 1,
        OutOfCity = 2,
        ParkingPickup = 3,
    }

    // этап 3: доставка автомобиля и страховой сбор
    private static double RunStageThree(int rentalDays, double amountAfterDiscounts)
    {
        Console.WriteLine();
        Console.WriteLine("--- Доставка и страховой сбор ---");

        DeliveryMethod deliveryMethod = ReadDeliveryMethod();
        double distanceKilometers = 0;

        if (deliveryMethod == DeliveryMethod.OutOfCity)
        {
            distanceKilometers = ReadDistanceKilometers();
        }

        bool isPremiumCar = ReadIsPremiumCar();

        double deliveryFee = CalculateDeliveryFee(deliveryMethod, rentalDays, distanceKilometers);
        double insuranceFee = CalculateInsuranceFee(amountAfterDiscounts, isPremiumCar);
        double finalTotal = (amountAfterDiscounts + insuranceFee) + deliveryFee;

        Console.WriteLine();
        Console.WriteLine($"Доставка: {deliveryFee}");
        Console.WriteLine($"Страховой сбор: {insuranceFee}");

        return finalTotal;
    }

    private static DeliveryMethod ReadDeliveryMethod()
    {
        DeliveryMethod deliveryMethod;
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("1 - Доставка в город");
            Console.WriteLine("2 - Доставка за город");
            Console.WriteLine("3 - Самовывоз с парковки");
            ShowPrompt(PromptType.DeliveryMethod);

            string input = Console.ReadLine() ?? "0";
            if (TryParseDeliveryMethod(input, out deliveryMethod))
            {
                break;
            }

            ShowError(ErrorType.InvalidDeliveryMethod);
        }

        return deliveryMethod;
    }

    private static double ReadDistanceKilometers()
    {
        double distanceKilometers;
        while (true)
        {
            ShowPrompt(PromptType.DistanceKilometers);

            string input = Console.ReadLine() ?? "0";
            if (TryParseNonNegativeNumber(input, out distanceKilometers))
            {
                break;
            }

            ShowError(ErrorType.InvalidDistance);
        }

        return distanceKilometers;
    }

    private static bool ReadIsPremiumCar()
    {
        while (true)
        {
            ShowPrompt(PromptType.IsPremiumCar);

            string input = Console.ReadLine() ?? "0";
            if (input.Trim() == "1")
            {
                return true;
            }

            if (input.Trim() == "0")
            {
                return false;
            }

            ShowError(ErrorType.InvalidPremiumChoice);
        }
    }

    private static bool TryParseDeliveryMethod(string input, out DeliveryMethod deliveryMethod)
    {
        if (!int.TryParse(input.Trim(), out int value))
        {
            deliveryMethod = default;
            return false;
        }

        if (value < 1 || value > 3)
        {
            deliveryMethod = default;
            return false;
        }

        deliveryMethod = (DeliveryMethod)value;
        return true;
    }

    private static bool TryParseNonNegativeNumber(string input, out double value)
    {
        string normalizedInput = input.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedInput, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            return false;
        }

        return value >= 0;
    }

    private static double CalculateDeliveryFee(DeliveryMethod deliveryMethod, int rentalDays, double distanceKilometers)
    {
        switch (deliveryMethod)
        {
            case DeliveryMethod.City:
                if (rentalDays > 14)
                {
                    return 0;
                }

                return 20;
            case DeliveryMethod.OutOfCity:
                return 15 + 2 * distanceKilometers;
            case DeliveryMethod.ParkingPickup:
                return 0;
            default:
                return 0;
        }
    }

    private static double CalculateInsuranceFee(double amountAfterDiscounts, bool isPremiumCar)
    {
        if (isPremiumCar)
        {
            double riskProfileRate = 0.05 + Random.Shared.NextDouble() * 0.10;
            return amountAfterDiscounts * riskProfileRate;
        }

        return amountAfterDiscounts * 0.08;
    }
}
