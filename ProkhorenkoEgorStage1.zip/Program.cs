﻿using System;

namespace practic2026
{
    struct Accruals
    {
        public double Salary;

        public int StandartWorkingHours;

        public int HourseWorking;
    }

    class Program
    {
        const int a = 1;
        const double proccent = 1.05;

        static void Main(string[] args)
        {
            double amount;

            Accruals accruals;


            Console.Write("Введите количество отработаных часов: ");
            accruals.HourseWorking = WriteInt();

            while (accruals.HourseWorking < 0)
            {
                ErrorOutPut("Ошибка, введите целое число");
                Console.Write("Введите количество отработаных часов: ");
                accruals.HourseWorking = WriteInt();
            }

            Console.Write("Введите количество часов: ");
            accruals.StandartWorkingHours = WriteInt();

            while (accruals.StandartWorkingHours < 0)
            {
                ErrorOutPut("Ошибка, введите целое число");
                Console.Write("Введите количество часов: ");
                accruals.StandartWorkingHours = WriteInt();
            }

            Console.Write("Введите оклад: ");
            accruals.Salary = WriteDouble();
            while (accruals.Salary < 0)
            {
                ErrorOutPut("Ошибка, введите целое число");
                Console.Write("Введите оклад: ");
                accruals.Salary = WriteInt();
            }

            double propotion = Propotion(accruals.HourseWorking, accruals.StandartWorkingHours);

            if (propotion > a)
            {
                double AboveNorm = propotion - a;
                double accrualwithsalary = AccrualWithSalary(AboveNorm, accruals.Salary, proccent);
                amount = accrualwithsalary + accruals.Salary;
            }
            else
            {
                amount = Accrual(propotion, accruals.Salary);
            }

            Console.WriteLine($"Итого: {amount:F2}");
        }

        static string? InPut()
        {
            return Console.ReadLine();
        }

        static void ErrorOutPut(string message)
        {
            Console.WriteLine(message);
        }

        static double Propotion(double HourseWorking, double StandartWorkingHours)
        {
            double propotion = HourseWorking / StandartWorkingHours;

            return propotion;
        }

        static double Accrual(double propotion, double salary)
        {
            double amount = salary * propotion;

            return amount;
        }

        static double AccrualWithSalary(double AboveNorm, double salary, double proccent)
        {
            double accrualwithsalary = AboveNorm * salary * proccent;

            return accrualwithsalary;
        }

        static int WriteInt()
        {
            string? input = InPut();

            if (TryParseWriteInt(input, out int value))
                return value;

            return 0;
        }

        static bool TryParseWriteInt(string? input, out int value)
        {
            value = 0;

            bool succses = double.TryParse(InPut(), out double result);

            return succses && value > 0;
        }

        static double WriteDouble()
        {
            string? input = InPut();

            if (TryParseWriteDouble(input, out double value))
                return value;

            return 0;
        }

        static bool TryParseWriteDouble(string? input, out double value)
        {
            value = 0;

            bool succses = double.TryParse(InPut(), out double result);

            return succses && value > 0;
        }
    }
}
