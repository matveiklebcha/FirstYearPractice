﻿using System;
using System.Globalization;

namespace HotelBooking
{
    class Program
    {
        private const double DiscountRate = 0.05;
        private const int DiscountThresholdNights = 3;
        private const int MinNights = 1;
        private const double MinPrice = 0.01;

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости бронирования номера в отеле\n");

            int nights = ReadPositiveInteger("Введите количество ночей: ");
            double pricePerNight = ReadPositiveDecimal("Введите стоимость номера за ночь: ");

            double totalPrice = CalculateBookingPrice(nights, pricePerNight);

            Console.WriteLine($"\nИтого: {totalPrice:F2}");
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine() ?? "";

                if (TryParsePositiveInteger(input, out int value))
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите целое число от {MinNights} и выше.");
            }
        }

        static double ReadPositiveDecimal(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine() ?? "";

                if (TryParsePositiveDecimal(input, out double value))
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите число больше {MinPrice:F2} (например, 150,50).");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;
            return int.TryParse(input, out value) && value >= MinNights;
        }

        static bool TryParsePositiveDecimal(string input, out double value)
        {
            value = 0;
            return double.TryParse(input, out value) && value >= MinPrice;
        }

        static double CalculateBookingPrice(int nights, double pricePerNight)
        {
            double basePrice = nights * pricePerNight;

            if (nights > DiscountThresholdNights)
            {
                return basePrice * (1 - DiscountRate);
            }

            return basePrice;
        }
    }
}