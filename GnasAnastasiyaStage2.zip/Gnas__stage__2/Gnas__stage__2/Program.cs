﻿// See https://aka.ms/new-console-template for more information
using System.Globalization;

namespace TaxiFareStage1
{
    internal class Program
    {
        private const string MoneyFormat = "0.00";
        private const decimal PercentScale = 100m;

        private const decimal MinimumBaseAfterDiscountFactor = 0.70m;

        private const decimal DistanceDiscountFromKmInclusive = 10m;
        private const decimal DistanceDiscountToKmExclusive = 30m;
        private const decimal DistanceDiscountPercentLow = 5m;
        private const decimal DistanceDiscountPercentHigh = 10m;

        private const decimal SubscriptionDiscountPercent = 7m;

        public struct TaxiTrip
        {
            public decimal DistanceKm { get; }
            public decimal RatePerKm { get; }
            public decimal PickupFee { get; }

            public TaxiTrip(decimal distanceKm, decimal ratePerKm, decimal pickupFee)
            {
                DistanceKm = distanceKm;
                RatePerKm = ratePerKm;
                PickupFee = pickupFee;
            }
        }

        public static void Main(string[] args)
        {
            decimal distanceKm = ReadPositiveDecimal("Расстояние поездки (км): ");
            decimal ratePerKm = ReadPositiveDecimal("Базовый тариф за километр: ");
            decimal pickupFee = ReadPositiveDecimal("Стартовая плата за подачу: ");

            bool hasActiveSubscription = ReadSubscriptionFlag();

            ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue);

            TaxiTrip trip = new TaxiTrip(distanceKm, ratePerKm, pickupFee);

            decimal totalPrice = CalculateTotalPrice(trip, hasActiveSubscription, hasPromoDiscount, promoIsPercent, promoValue);

            Console.WriteLine($"Итого: {totalPrice.ToString(MoneyFormat, CultureInfo.InvariantCulture)}");
        }

        private static decimal CalculateTotalPrice(TaxiTrip trip, bool hasActiveSubscription, bool hasPromoDiscount, bool promoIsPercent, decimal promoValue)
        {
            decimal baseAmountWithoutPickupFee = trip.DistanceKm * trip.RatePerKm;
            decimal minimumAllowedBase = baseAmountWithoutPickupFee * MinimumBaseAfterDiscountFactor;

            decimal currentBase = baseAmountWithoutPickupFee;

            currentBase = ApplyDistanceDiscount(currentBase, trip.DistanceKm);
            if (hasPromoDiscount)
            {
                currentBase = ApplyPromoDiscount(currentBase, promoIsPercent, promoValue);
            }

            if (hasActiveSubscription)
            {
                currentBase = ApplySubscriptionDiscount(currentBase); 
            }
          

            if (currentBase < minimumAllowedBase)
            {
                currentBase = minimumAllowedBase;
            }

            return trip.PickupFee + currentBase;
        }

        private static decimal ApplyDistanceDiscount(decimal baseAmount, decimal distanceKm)
        {
            if (distanceKm < DistanceDiscountFromKmInclusive)
            {
                return baseAmount;
            }

            decimal discountPercent;

            if (distanceKm < DistanceDiscountToKmExclusive)
            {
                discountPercent = DistanceDiscountPercentLow;
            }
            else
            {
                discountPercent = DistanceDiscountPercentHigh;
            }

            decimal discountFraction = discountPercent / PercentScale;
            return baseAmount * (1m - discountFraction);
        }

        private static decimal ApplyPromoDiscount(decimal baseAmount, bool promoIsPercent, decimal promoValue)
        {
            
            if (promoIsPercent)
            {
                decimal discountFraction = promoValue / PercentScale;
                return baseAmount * (1m - discountFraction);
            }

            if (baseAmount == 0m)
            {
                return 0m;
            }

            decimal effectiveDiscountFraction = promoValue / baseAmount;
            decimal discounted = baseAmount * (1m - effectiveDiscountFraction);

            return discounted < 0m ? 0m : discounted;
        }

        private static decimal ApplySubscriptionDiscount(decimal baseAmount)
        {
            

            decimal discountFraction = SubscriptionDiscountPercent / PercentScale;
            return baseAmount * (1m - discountFraction);
        }

        private static bool ReadSubscriptionFlag()
        {
            while (true)
            {
                Console.Write("Активная подписка? (yes/no): ");
                string? input = Console.ReadLine();

                if (input == null)
                {
                    Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
                    continue;
                }

                string normalized = input.Trim().ToLowerInvariant();

                if (normalized == "y" || normalized == "yes" || normalized == "да")
                {
                    return true;
                }

                if (normalized == "n" || normalized == "no" || normalized == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
            }
        }

        private static void ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue)
        {
            hasPromoDiscount = false;
            promoIsPercent = false;
            promoValue = 0m;

            while (true)
            {
                Console.Write("Промокод (пусто = нет скидки). Пример: 10% (процент) или 50 (фикс): ");
                string? input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    return;
                }

                string normalized = input.Trim().Replace(',', '.');

                if (normalized.EndsWith("%"))
                {
                    string numberPart = normalized[..^1].Trim();

                    if (TryParseDecimal(numberPart, out decimal percent) && percent > 0m && percent <= 100m)
                    {
                        hasPromoDiscount = true;
                        promoIsPercent = true;
                        promoValue = percent;
                        return;
                    }

                    Console.WriteLine("Ошибка: процент должен быть числом от 1 до 100.");
                    continue;
                }

                if (TryParseDecimal(normalized, out decimal fixedAmount) && fixedAmount > 0m)
                {
                    hasPromoDiscount = true;
                    promoIsPercent = false;
                    promoValue = fixedAmount;
                    return;
                }

                Console.WriteLine("Ошибка: фиксированная скидка должна быть числом больше 0.");
            }
        }

        private static decimal ReadPositiveDecimal(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out decimal value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: введите число больше 0.");
            }
        }

        private static bool TryParsePositiveDecimal(string? input, out decimal value)
        {
            value = 0m;

            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }

            string normalized = input.Trim().Replace(',', '.');

            bool success = decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value);

            return success && value > 0m;
        }

        private static bool TryParseDecimal(string input, out decimal value)
        {
            return decimal.TryParse(input, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
        }
    }
}