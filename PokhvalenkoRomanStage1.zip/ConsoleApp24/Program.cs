﻿using System;

namespace ConsoleApp24
{
    class Program
    {
        private const double DiscountRate = 0.05;
        private const int DiscountThresholdMonths = 3;

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости абонемента в фитнес-клуб\n");
            int membershipMonths = ReadPositiveInteger("Введите срок абонемента в месяцах: ");
            double pricePerMonth = ReadPositiveDecimal("Введите стоимость за месяц: ");
            double totalPrice = CalculateMembershipPrice(membershipMonths, pricePerMonth);
            Console.WriteLine($"\nИтого: {totalPrice:F2}");
        }

        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveInteger(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Число введено неверно.");
            }
        }

        static double ReadPositiveDecimal(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Число введено неверно.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveDecimal(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static double CalculateMembershipPrice(int months, double pricePerMonth)
        {
            double basePrice = months * pricePerMonth;

            if (months > DiscountThresholdMonths)
            {
                return basePrice * (1 - DiscountRate);
            }

            return basePrice;
        }
    }
}