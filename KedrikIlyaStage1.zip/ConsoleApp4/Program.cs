﻿namespace ConsoleApp4;

internal static class Program
{
    private const int DiscountDayThreshold = 7;
    private const double DiscountRate = 0.05;

    private static void Main()
    {

        while (true)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("========== МЕНЮ ==========");
            Console.WriteLine("1 - Посчитать стоимость аренды авто");
            Console.WriteLine("2 - Выход");
            ShowPrompt(PromptType.MenuChoice);

            switch (Console.ReadLine())
            {
                case "1":
                    CalculateAndShowRentalCost();
                    break;
                case "2":
                    Console.WriteLine("Программа завершена.");
                    return;
                default:
                    ShowError(ErrorType.InvalidMenuChoice);
                    break;
            }
        }
    }

    private static void CalculateAndShowRentalCost()
    {
        int rentalDays;
        do
        {
            ShowPrompt(PromptType.RentalDays);
            rentalDays = ReadPositiveInteger();
        }
        while (rentalDays == 0);

        double dailyRate;
        do
        {
            ShowPrompt(PromptType.DailyRate);
            dailyRate = ReadPositiveNumber();
        }
        while (dailyRate == 0);

        Console.WriteLine($"Итого: {CalculateTotalAmount(rentalDays, dailyRate)}");
        Console.WriteLine("нажмите клавишу");
        Console.ReadKey();
    }

    private static int ReadPositiveInteger()
    {
        string input = Console.ReadLine() ?? "";
        bool result = int.TryParse(input, out int value);

        if (!result || value <= 0)
        {
            Console.Clear();
            ShowError(ErrorType.InvalidInteger);
            return 0;
        }

        return value;
    }

    private static double ReadPositiveNumber()
    {
        string input = Console.ReadLine() ?? "";
        bool result = double.TryParse(input, out double value);

        if (!result || value <= 0)
        {
            Console.Clear();
            ShowError(ErrorType.InvalidNumber);
            return 0;
        }

        return value;
    }

    private static void ShowPrompt(PromptType promptType)
    {
        string prompt = promptType switch
        {
            PromptType.MenuChoice => "Введите номер пункта: ",
            PromptType.RentalDays => "Введите количество дней аренды: ",
            PromptType.DailyRate => "Введите стоимость аренды за 1 день: ",
            _ => string.Empty,
        };

        Console.Write(prompt);
    }

    private static void ShowError(ErrorType errorType)
    {
        string message = errorType switch
        {
            ErrorType.InvalidMenuChoice => "Нет такого пункта меню!",
            ErrorType.InvalidInteger => "Ошибка! Нужно ввести целое число больше 0",
            ErrorType.InvalidNumber => "Ошибка! Нужно ввести число больше 0",
            _ => "Неизвестная ошибка",
        };

        Console.WriteLine(message);
    }

    private enum PromptType
    {
        MenuChoice,
        RentalDays,
        DailyRate,
    }

    private enum ErrorType
    {
        InvalidMenuChoice,
        InvalidInteger,
        InvalidNumber,
    }

    private static double CalculateTotalAmount(int rentalDays, double dailyRate)
    {
        if (rentalDays <= DiscountDayThreshold)
        {
            return rentalDays * dailyRate;
        }

        return rentalDays * dailyRate * (1 - DiscountRate);
    }
}
