﻿using System;
using System.Collections.Generic;
using System.IO;

namespace intership_LOL_XD
{
    internal class Program
    {
        private const double DiscountTier1Threshold = 3;
        private const double DiscountTier2Threshold = 10;
        private const double DiscountTier1Rate = 0.05;
        private const double DiscountTier2Rate = 0.12;
        private const double FanClubDiscountRate = 0.08;
        private const double MaxTotalPercentDiscount = 0.25;

        private const string PromoFilePath = "promo.txt";

        
        public struct Ticket
        {
            public string Category { get; set; }
            public double Price { get; set; }

            public Ticket(string category, double price)
            {
                Category = category;
                Price = price;
            }
        }

        static void Main()
        {
            Console.WriteLine(AppDomain.CurrentDomain.BaseDirectory); 
            Console.WriteLine("Расчёт стоимости билетов на концерт\n");
            string[] promoLines = LoadPromoCodes(PromoFilePath);
            int ticketCount = ReadPositiveInteger("Введите количество билетов: ");
            List<Ticket> tickets = ReadTickets(ticketCount);
            bool isFanClubMember = ReadYesNo("Подписчик фан-клуба? (да/нет): ");
            double promoDiscount = ReadPromoCode(promoLines); 
            double baseSum = CalculateBaseSum(tickets);
            double finalSum = CalculateTotalPrice(baseSum, ticketCount, isFanClubMember, promoDiscount);

            Console.WriteLine($"\nИтого: {finalSum:F2}");
        }
        static string[] LoadPromoCodes(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл не найден");
                return [];
            }
            string[] lines = File.ReadAllLines(filePath);
            return lines;
        }
        static double ReadPromoCode(string[] promoLines)
        {
            while (true)
            {
                Console.Write("Введите промокод (или оставьте пустым): ");
                string? input = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(input))
                    return 0;

                foreach (string line in promoLines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    string[] parts = line.Split([';'], 2);
                    if (parts.Length == 2)
                    {
                        string code = parts[0];
                        if (string.Equals(code, input, StringComparison.OrdinalIgnoreCase))
                        {
                            if (double.TryParse(parts[1].Trim(), out double percent) && percent >= 0)
                            {
                                double discountAbsolute = percent; 
                                Console.WriteLine($"Промокод принят! Скидка {discountAbsolute} руб.");
                                return discountAbsolute;
                            }
                        }
                    }
                }
                Console.WriteLine("Промокод не найден. Попробуйте ещё раз.");
            }
        }
        static List<Ticket> ReadTickets(int count)
        {
            var tickets = new List<Ticket>(count);
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"\nБилет #{i + 1}:");
                tickets.Add(ReadTicket());
            }
            return tickets;
        }

        static Ticket ReadTicket()
        {
            string category = ReadNonEmptyString("Введите категорию места (портер, танцпол и т.д.): ");
            double price = ReadPositiveDouble("Введите цену билета: ");
            return new Ticket(category, price);
        }

        static string ReadNonEmptyString(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(input)) return input;
                Console.WriteLine("Ошибка: Категория не может быть пустой.");
            }
        }

        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveInteger(input, out int value)) return value;
                Console.WriteLine("Ошибка: Введите положительное целое число.");
            }
        }

        static double ReadPositiveDouble(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveDouble(input, out double value)) 
                    return value;
                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }

        static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine()?.Trim().ToLower();
                if (input == "да" || input == "yes" || input == "y" || input == "д") 
                    return true;
                if (input == "нет" || input == "no" || input == "n" || input == "н") 
                    return false;
                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;
            if (int.TryParse(input, out int parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }

        static bool TryParsePositiveDouble(string input, out double value)
        {
            value = 0;
            if (double.TryParse(input, out double parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }

        static double CalculateBaseSum(List<Ticket> tickets)
        {
            double sum = 0;
            foreach (var t in tickets) sum += t.Price;
            return sum;
        }

        static double CalculateQuantityDiscount(int ticketCount)
        {
            if (ticketCount >= DiscountTier2Threshold) return DiscountTier2Rate;
            if (ticketCount >= DiscountTier1Threshold) return DiscountTier1Rate;
            return 0;
        }

        static double CalculateTotalPrice(double basePrice, int ticketCount, bool isFanClubMember, double promoDiscountAbsolute)
        {
            double quantityDiscount = CalculateQuantityDiscount(ticketCount);
            double fanClubDiscount = isFanClubMember ? FanClubDiscountRate : 0;
            double totalPercentDiscount = Math.Min(quantityDiscount + fanClubDiscount, MaxTotalPercentDiscount);
            double priceAfterPercent = basePrice * (1 - totalPercentDiscount);
            double finalPrice = priceAfterPercent - promoDiscountAbsolute;
            return Math.Max(finalPrice, 0);
        }
    }
}