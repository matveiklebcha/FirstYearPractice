﻿internal class Program
{
	struct Ticket
	{
		public string typePlace;
		public decimal price;
	}

	public static readonly Dictionary<string, string> Messages = new Dictionary<string, string>
	{
		{ "EmptyType", "Тип места не может быть пустым!" },
		{ "InvalidPrice", "Цена должна быть положительным числом!" },
		{ "InvalidChoice", "Введите да или нет." }
	};

	public static readonly Dictionary<string, decimal> promoCodes = new Dictionary<string, decimal>
	{
		{ "STUDENT", 2m },
		{ "SCHOOL", 1.5m },
		{ "VIP", 3.0m }
	};
	private static void Main(string[] args)
	{
		List<Ticket> tickets = CreateListTicket();

		Console.Write("Есть ли у вас карта кинотеатра? (да/нет): ");
		string cardAnswer = Console.ReadLine() ?? "нет";
		bool hasCard = IsValidAnswer(cardAnswer);

		Console.Write("Есть ли у вас промокод? (да/нет): ");
		string promoAnswer = Console.ReadLine() ?? "нет";
		string promoCode = "";
		if (IsValidAnswer(promoAnswer))
		{
			Console.Write("Введите промокод: ");
			promoCode = Console.ReadLine()?.Trim().ToUpper() ?? "";
		}

		decimal finalPrice = CalculateFinalPrice(tickets, hasCard, promoCode);
		decimal percentage = CalculateTotalPercentage(tickets, hasCard);
		PrintTickets(finalPrice, percentage);
	}
	static decimal CalculateFinalPrice(List<Ticket> tickets, bool hasCard, string promoCode)
	{
		decimal total = PriceReservation(tickets);
		decimal percentage = CalculateTotalPercentage(tickets, hasCard);
		decimal afterPercentDiscount = ApplyPercentageDiscount(total, percentage);
		if (CheckPromoCode(promoCode))
		{
			decimal discountPerTicket = promoCodes[promoCode];
			afterPercentDiscount = ApplyPromoCodeDiscount(tickets, discountPerTicket, afterPercentDiscount);
			Console.WriteLine($"Применён промокод {promoCode}: скидка {discountPerTicket} у.е. за билет.");
		}
		return afterPercentDiscount;
	}

	static decimal GetQuantityDiscount(int ticketCount)
	{
		if (ticketCount >= 4 && ticketCount < 8)
		{
			return 0.05m;
		}
		if (ticketCount >= 8)
		{
			return 0.15m;
		}
		return 0;
	}

	static decimal GetCardDiscount(bool hasCard)
	{
		if (hasCard)
		{
			return 0.10m;
		}
		return 0;
	}

	static decimal CalculateTotalPercentage(List<Ticket> tickets, bool hasCard)
	{
		decimal percentage = GetQuantityDiscount(tickets.Count) + GetCardDiscount(hasCard);
		if (percentage > 0.25m)
		{
			percentage = 0.25m;
		}
		return percentage;
	}

	static decimal ApplyPercentageDiscount(decimal total, decimal percentage)
	{
		return total - (total * percentage);
	}

	static bool CheckPromoCode(string promocode)
	{
		if (promoCodes.ContainsKey(promocode.ToUpper()))
		{
			return true;
		}
		return false;
	}

	static decimal ApplyPromoCodeDiscount(List<Ticket> tickets, decimal discountPerTicket, decimal amountAfterPercent)
	{
		return amountAfterPercent - (discountPerTicket * tickets.Count);
	}
	static bool IsValidAnswer(string InPut)
	{
		if (InPut.Trim().ToLower() == "да")
		{
			return true;
		}
		return false;
	}

	static bool IsValidString(string str)
	{
		if (!string.IsNullOrEmpty(str))
		{
			return true;
		}
		return false;
	}

	static bool TryParsePositiveDecimal(string input, out decimal result)
	{
		if (decimal.TryParse(input, out result) && result > 0)
		{
			return true;
		}
		result = 0;
		return false;
	}

	static void ShowError(string key)
	{
		Console.WriteLine(Messages[key]);
	}

	static Ticket InputSingleTicket()
	{
		string typePlace;
		while (true)
		{
			Console.Write("Введите тип места: ");
			typePlace = Console.ReadLine()?.Trim() ?? "";
			if (IsValidString(typePlace))
			{
				break;
			}
			ShowError("EmptyType");
		}

		decimal price;
		while (true)
		{
			Console.Write("Введите цену билета: ");
			string input = Console.ReadLine() ?? "0";
			if (TryParsePositiveDecimal(input, out price))
			{
				break;
			}
			ShowError("InvalidPrice");
		}

		return new Ticket { typePlace = typePlace, price = price };
	}

	static List<Ticket> CreateListTicket()
	{
		List<Ticket> tickets = new List<Ticket>();

		while (true)
		{
			tickets.Add(InputSingleTicket());
			while (true)
			{
				Console.Write("\nХотите добавить еще один билет? (да/нет): ");
				string choice = Console.ReadLine() ?? "";
				if (choice.ToLower() == "да")
				{
					break;
				}
				if (choice.ToLower() == "нет")
				{
					return tickets;
				}
				ShowError("InvalidChoice");
			}
		}
	}

	static decimal PriceReservation(List<Ticket> tickets)
	{
		decimal summarizePrice = 0;
		foreach (Ticket item in tickets)
		{
			summarizePrice += item.price;
		}
		return summarizePrice;
	}

	static void PrintTickets(decimal finalPrice, decimal percentage)
	{
		Console.WriteLine($"Итоговая сумма: {finalPrice:F2}");
		if (percentage > 0)
		{
			Console.WriteLine($"Суммарная процентная скидка: {percentage * 100}%");
		}
		else
		{
			Console.WriteLine("Процентная скидка не применялась.");
		}
	}
}