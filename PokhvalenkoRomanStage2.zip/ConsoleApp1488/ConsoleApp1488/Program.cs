﻿ using System;

namespace MembershipPriceCalculator
{
    class Program
    {
        private const double DiscountRateThreeToTwelveMonths = 0.05;
        private const double DiscountRateTwelveMonthsAndMore = 0.15;
        private const int DiscountThresholdMonthsLower = 3;
        private const int DiscountThresholdMonthsUpper = 12;
        private const double StudentDiscountRate = 0.10;

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости абонемента в фитнес-клуб\n");

            int membershipMonths = ReadPositiveInteger("Введите срок абонемента в месяцах: ");
            double pricePerMonth = ReadPositiveDecimal("Введите стоимость за месяц: ");
            double referralDiscount = ReadReferralDiscount("Введите скидку по реферальному коду на первый месяц: ");
            bool isStudent = ReadStudentStatus("Есть ли у вас студенческий статус? (да/нет): ");

            double totalPrice = CalculateMembershipPrice(membershipMonths, pricePerMonth, referralDiscount, isStudent);
            Console.WriteLine($"\nИтого: {totalPrice:F2}");
        }

        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveInteger(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите целое положительное число.");
            }
        }

        static double ReadPositiveDecimal(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }

        static double ReadReferralDiscount(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParseReferralDiscount(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите неотрицательное число.");
            }
        }

        static bool ReadStudentStatus(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да" )
                {
                    return true;
                }

                if (input == "нет" )
                {
                    return false;
                }

                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveDecimal(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParseReferralDiscount(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue >= 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }
 static double CalculateMembershipPrice(int months, double pricePerMonth, double referralDiscount, bool isStudent)
        {
            double basePrice = months * pricePerMonth;

            double totalDiscountRate = CalculateTotalDiscountRate(months, isStudent);
            double priceAfterPercentageDiscount = basePrice * (1 - totalDiscountRate);

            double finalPrice = ApplyReferralDiscount(priceAfterPercentageDiscount, pricePerMonth, referralDiscount, months);

            return finalPrice;
        }

        static double CalculateTotalDiscountRate(int months, bool isStudent)
        {
            double discountRate = 0;

            if (months >= DiscountThresholdMonthsLower && months < DiscountThresholdMonthsUpper)
            {
                discountRate += DiscountRateThreeToTwelveMonths;
            }
            else if (months >= DiscountThresholdMonthsUpper)
            {
                discountRate += DiscountRateTwelveMonthsAndMore;
            }

            if (isStudent)
            {
                discountRate += StudentDiscountRate;
            }

            return discountRate;
        }

        static double ApplyReferralDiscount(double priceAfterPercentageDiscount, double pricePerMonth, double referralDiscount, int months)
        {
            if (months >= 1)
            {
                double firstMonthPrice = pricePerMonth;
                double discountedFirstMonthPrice = Math.Max(0, firstMonthPrice - referralDiscount);
                return priceAfterPercentageDiscount - (firstMonthPrice - discountedFirstMonthPrice);
            }

            return priceAfterPercentageDiscount;
        }
    }
}
