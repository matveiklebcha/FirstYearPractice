﻿using System;
using System.Globalization;

namespace HotelBooking
{
    class Program
    {
        // Константы скидок
        private const double DiscountRate5 = 0.05;
        private const double DiscountRate12 = 0.12;
        private const double BonusProgramDiscount = 0.08;
        private const double MaxDiscountPercent = 0.20;

        // Пороги скидок
        private const int DiscountThreshold5 = 3;
        private const int DiscountThreshold12 = 7;

        // Константы для валидации
        private const int MinNights = 1;
        private const double MinPrice = 0.01;
        private const double MinPromoDiscount = 0.0;

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости бронирования номера в отеле\n");

            int nights = ReadPositiveInteger("Введите количество ночей: ");
            double pricePerNight = ReadPositiveDouble("Введите стоимость номера за ночь: ");

            double promoDiscount = ReadPositiveDouble("Введите скидку по промокоду (0, если промокода нет): ", MinPromoDiscount);

            bool isBonusMember = ReadBonusProgramStatus();

            double totalPrice = CalculateBookingPrice(nights, pricePerNight, promoDiscount, isBonusMember);

            Console.WriteLine($"\nИтого: {totalPrice:F2}");

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static int ReadPositiveInteger(string prompt, int min = MinNights)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine() ?? "";

                if (int.TryParse(input, out int value) && value >= min)
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите целое число от {min}.");
            }
        }

        static double ReadPositiveDouble(string prompt, double min = MinPrice)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine() ?? "";

                if (double.TryParse(input, out double value) && value >= min)
                {
                    return value;
                }

                Console.WriteLine($"Ошибка: Введите число не меньше {min:F2}.");
            }
        }

        static bool ReadBonusProgramStatus()
        {
            Console.WriteLine("\nУчастник бонусной программы?");
            Console.WriteLine("0 - Нет");
            Console.WriteLine("1 - Да");

            while (true)
            {
                int choice = ReadPositiveInteger("Ваш выбор (0-1): ", 0);

                if (choice == 0)
                {
                    return false;
                }

                if (choice == 1)
                {
                    return true;
                }

                Console.WriteLine("Ошибка: выберите 0 или 1.");
            }
        }

        static double CalculateBookingPrice(int nights, double pricePerNight, double promoDiscount, bool isBonusMember)
        {
            double basePrice = nights * pricePerNight;

            double discountPercent = CalculateStayDiscount(nights);

            if (isBonusMember)
            {
                discountPercent += BonusProgramDiscount;
            }

            if (discountPercent > MaxDiscountPercent)
            {
                discountPercent = MaxDiscountPercent;
            }

            double totalPrice = basePrice * (1 - discountPercent);

            totalPrice -= promoDiscount;

            if (totalPrice < 0)
            {
                totalPrice = 0;
            }

            return totalPrice;
        }

        static double CalculateStayDiscount(int nights)
        {
            if (nights >= DiscountThreshold12)
            {
                return DiscountRate12;
            }

            if (nights >= DiscountThreshold5)
            {
                return DiscountRate5;
            }

            return 0;
        }
    }
}