﻿// See https://aka.ms/new-console-template for more information
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.Json;

namespace Gnas_stage_4_trial
{
    internal class Program
    {
        private const string PromoUsageJsonFileName = "promo_usage.json";

        private static readonly JsonSerializerOptions JsonSerializerOptions = new() { WriteIndented = true };

        private static bool isPromoUsageChanged;

        public static void Main(string[] args)
        {
            Dictionary<string, List<string>> usedPromoCodesByPassenger = new(StringComparer.OrdinalIgnoreCase);

            LoadUsedPromoCodesFromJson(usedPromoCodesByPassenger);

            decimal distanceKm = ReadPositiveDecimal("Расстояние поездки (км): ");
            decimal ratePerKm = ReadPositiveDecimal("Базовый тариф за километр: ");
            decimal pickupFee = ReadPositiveDecimal("Стартовая плата за подачу: ");

            string passengerIdentifier = ReadPassengerIdentifier();

            bool hasActiveSubscription = ReadSubscriptionFlag();

            ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue, out string promoCodeKey);

            if (hasPromoDiscount)
            {
                bool promoWasMarkedAsUsed = TryMarkPromoCodeAsUsed(usedPromoCodesByPassenger, passengerIdentifier, promoCodeKey);

                if (!promoWasMarkedAsUsed)
                {
                    hasPromoDiscount = false;
                    Console.WriteLine("Промокод уже применён этим пассажиром. Скидка не применяется.");
                }
                else
                {
                    Console.WriteLine("Промокод успешно применён для этого пассажира.");
                }
            }

            bool isAirportTrip = ReadAirportFlag();

            int tariffChoice = ReadTariffChoice(distanceKm);
            decimal idleMinutes = 0m;

            if (tariffChoice == Constants.TariffIdleTime)
            {
                idleMinutes = ReadPositiveDecimal("Сколько минут простоя: ");
            }

            TaxiTrip trip = new(distanceKm, ratePerKm, pickupFee);

            decimal totalPrice = trip.CalculateTotalPrice(hasActiveSubscription, hasPromoDiscount, promoIsPercent, promoValue, isAirportTrip, tariffChoice, idleMinutes); 


            Console.WriteLine($"Итого: {totalPrice.ToString(Constants.MoneyFormat, CultureInfo.InvariantCulture)}");

            if (isPromoUsageChanged)
            {
                SaveUsedPromoCodesToJson(usedPromoCodesByPassenger);
            }
        }

        private static void LoadUsedPromoCodesFromJson(Dictionary<string, List<string>> usedPromoCodesByPassenger)
        {
            usedPromoCodesByPassenger.Clear();
            isPromoUsageChanged = false;

            string jsonPath = Path.Combine(AppContext.BaseDirectory, PromoUsageJsonFileName);

            if (!File.Exists(jsonPath))
            {
                return;
            }

            string json = File.ReadAllText(jsonPath);
            if (string.IsNullOrWhiteSpace(json))
            {
                return;
            }

            try
            {
                Dictionary<string, List<string>> data = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(json, JsonSerializerOptions) ?? [];

                foreach (KeyValuePair<string, List<string>> entry in data)
                {
                    if (string.IsNullOrWhiteSpace(entry.Key))
                    {
                        continue;
                    }

                    List<string> promosForPassenger = new();

                    if (entry.Value != null)
                    {
                        foreach (string promo in entry.Value)
                        {
                            if (!string.IsNullOrWhiteSpace(promo))
                            {
                                promosForPassenger.Add(promo.Trim());
                            }
                        }
                    }

                    usedPromoCodesByPassenger[entry.Key.Trim()] = promosForPassenger;
                }
            }
            catch
            {
                usedPromoCodesByPassenger.Clear();
                isPromoUsageChanged = false;
            }
        }

        private static void SaveUsedPromoCodesToJson(Dictionary<string, List<string>> usedPromoCodesByPassenger)
        {
            string jsonPath = Path.Combine(AppContext.BaseDirectory, PromoUsageJsonFileName);

            string json = JsonSerializer.Serialize(usedPromoCodesByPassenger, JsonSerializerOptions);
            File.WriteAllText(jsonPath, json);

            isPromoUsageChanged = false;
        }

        private static bool TryMarkPromoCodeAsUsed(Dictionary<string, List<string>> usedPromoCodesByPassenger, string passengerIdentifier, string promoCodeKey)
        {
            if (string.IsNullOrWhiteSpace(passengerIdentifier))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(promoCodeKey))
            {
                return false;
            }

            if (!usedPromoCodesByPassenger.TryGetValue(passengerIdentifier, out List<string>? usedPromos))
            {
                usedPromos = new List<string>();
                usedPromoCodesByPassenger[passengerIdentifier] = usedPromos;
            }

            if (IsPromoAlreadyUsed(usedPromos, promoCodeKey))
            {
                return false;
            }

            usedPromos.Add(promoCodeKey);
            isPromoUsageChanged = true;
            return true;
        }

        private static bool IsPromoAlreadyUsed(List<string> usedPromos, string promoCodeKey)
        {
            foreach (string usedPromo in usedPromos)
            {
                if (string.Equals(usedPromo, promoCodeKey, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool ReadSubscriptionFlag()
        {
            while (true)
            {
                Console.Write("Активная подписка? (yes/no): ");
                string input = Console.ReadLine() ?? "";

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
                    continue;
                }

                string normalized = input.Trim().ToLowerInvariant();

                if (normalized == "y" || normalized == "yes" || normalized == "да")
                {
                    return true;
                }

                if (normalized == "n" || normalized == "no" || normalized == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
            }
        }

        private static bool ReadAirportFlag()
        {
            while (true)
            {
                Console.Write("Поездка в аэропорт? (yes/no): ");
                string input = Console.ReadLine() ?? "";

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
                    continue;
                }

                string normalized = input.Trim().ToLowerInvariant();

                if (normalized == "y" || normalized == "yes" || normalized == "да")
                {
                    return true;
                }

                if (normalized == "n" || normalized == "no" || normalized == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: введите yes или no (y/n, да/нет).");
            }
        }

        private static string ReadPassengerIdentifier()
        {
            while (true)
            {
                Console.Write("Введите идентификатор пассажира: ");
                string input = Console.ReadLine() ?? "";

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка: идентификатор не должен быть пустым.");
                    continue;
                }

                return input.Trim();
            }
        }

        private static int ReadTariffChoice(decimal distanceKm)
        {
            while (true)
            {
                Console.WriteLine("Выберите тариф:");
                Console.WriteLine("1 - Подача к подъезду (50; бесплатно если расстояние > 20 км)");
                Console.WriteLine("2 - Эконом-маршрут (стартовая плата + 1.5 у.е./км)");
                Console.WriteLine("3 - Расчёт по простою (0.3 у.е. за минуту простоя)");
                Console.WriteLine("4 - Премиум-электромобиль (30 + 0.8 × км; доступен только если расстояние > 5 км)");
                Console.Write("Ваш выбор (1/2/3/4): ");

                string input = Console.ReadLine() ?? "";
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка: введите 1, 2, 3 или 4.");
                    continue;
                }

                string normalized = input.Trim();

                if (!int.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out int tariff))
                {
                    Console.WriteLine("Ошибка: введите 1, 2, 3 или 4.");
                    continue;
                }

                bool isValidTariff = tariff == Constants.TariffPickupToBuilding || tariff == Constants.TariffEconomRoute || tariff == Constants.TariffIdleTime || tariff == Constants.TariffPremiumElectricCar;

                if (!isValidTariff)
                {
                    Console.WriteLine("Ошибка: введите 1, 2, 3 или 4.");
                    continue;
                }

                if (tariff == Constants.TariffPremiumElectricCar && distanceKm <= Constants.PremiumElectricCarMinDistanceKmExclusive)
                {
                    Console.WriteLine("Ошибка: тариф 4 доступен только при расстоянии > 5 км.");
                    continue;
                }

                return tariff;
            }
        }

        private static void ReadPromoDiscount(out bool hasPromoDiscount, out bool promoIsPercent, out decimal promoValue, out string promoCodeKey)
        {
            hasPromoDiscount = false;
            promoIsPercent = false;
            promoValue = 0m;
            promoCodeKey = string.Empty;

            while (true)
            {
                Console.Write("Промокод (пусто = нет скидки). Пример: 10% (процент) или 50 (фикс): ");
                string input = Console.ReadLine() ?? "";

                if (string.IsNullOrWhiteSpace(input))
                {
                    return;
                }

                string normalized = input.Trim().Replace(',', '.');
                promoCodeKey = normalized;

                if (normalized.EndsWith("%"))
                {
                    string numberPart = normalized[..^1].Trim();

                    if (TryParseDecimal(numberPart, out decimal percent) && percent > 0m && percent <= 100m)
                    {
                        hasPromoDiscount = true;
                        promoIsPercent = true;
                        promoValue = percent;
                        return;
                    }

                    Console.WriteLine("Ошибка: процент должен быть числом от 1 до 100.");
                    continue;
                }

                if (TryParseDecimal(normalized, out decimal fixedAmount) && fixedAmount > 0m)
                {
                    hasPromoDiscount = true;
                    promoIsPercent = false;
                    promoValue = fixedAmount;
                    return;
                }

                Console.WriteLine("Ошибка: фиксированная скидка должна быть числом больше 0.");
            }
        }

        private static decimal ReadPositiveDecimal(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out decimal value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: введите число больше 0.");
            }
        }

        private static bool TryParsePositiveDecimal(string? input, out decimal value)
        {
            value = 0m;

            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }

            string normalized = input.Trim().Replace(',', '.');

            bool success = decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
            return success && value > 0m;
        }

        private static bool TryParseDecimal(string input, out decimal value)
        {
            return decimal.TryParse(input, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
        }
    }
}
