﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gnas_stage_4_trial;

internal struct TaxiTrip
{
    public decimal DistanceKm { get; }
    public decimal RatePerKm { get; }
    public decimal PickupFee { get; }

    public TaxiTrip(decimal distanceKm, decimal ratePerKm, decimal pickupFee)
    {
        DistanceKm = distanceKm;
        RatePerKm = ratePerKm;
        PickupFee = pickupFee;
    }

    public decimal CalculateTotalPrice(bool hasActiveSubscription, bool hasPromoDiscount, bool promoIsPercent, decimal promoValue, bool isAirportTrip, int tariffChoice, decimal idleMinutes)
    {
        decimal baseAmountWithoutPickupFee = CalculateBaseAmountWithoutPickupFee();
        decimal minimumAllowedBase = baseAmountWithoutPickupFee * Constants.MinimumBaseAfterDiscountFactor;

        decimal baseAfterDistanceDiscount = ApplyDistanceDiscount(baseAmountWithoutPickupFee);
        decimal baseAfterSubscriptionDiscount = hasActiveSubscription ? ApplySubscriptionDiscount(baseAmountWithoutPickupFee) : baseAmountWithoutPickupFee;

        decimal baseAfterMaximumOfDistanceAndSubscriptionDiscount = Math.Min(baseAfterDistanceDiscount, baseAfterSubscriptionDiscount);

        decimal baseAfterPromoDiscount = hasPromoDiscount ? ApplyPromoDiscount(baseAfterMaximumOfDistanceAndSubscriptionDiscount, promoIsPercent, promoValue) : baseAfterMaximumOfDistanceAndSubscriptionDiscount;

        if (baseAfterPromoDiscount < minimumAllowedBase)
        {
            baseAfterPromoDiscount = minimumAllowedBase;
        }

        decimal serviceCommission = CalculateServiceCommission(baseAfterPromoDiscount, isAirportTrip);
        decimal tariffFee = CalculateTariffFee(tariffChoice);
        decimal idleFee = CalculateIdleFee(tariffChoice, idleMinutes);

        return baseAfterPromoDiscount + serviceCommission + tariffFee + idleFee;
    }

    private decimal CalculateBaseAmountWithoutPickupFee()
    {
        return DistanceKm * RatePerKm;
    }

    private decimal ApplyDistanceDiscount(decimal baseAmount)
    {
        if (DistanceKm < Constants.DistanceDiscountFromKmInclusive)
        {
            return baseAmount;
        }

        decimal discountPercent = DistanceKm < Constants.DistanceDiscountToKmExclusive ? Constants.DistanceDiscountPercentLow : Constants.DistanceDiscountPercentHigh;

        decimal discountFraction = discountPercent / Constants.PercentScale;
        return baseAmount * (1m - discountFraction);
    }

    private decimal ApplyPromoDiscount(decimal baseAmount, bool promoIsPercent, decimal promoValue)
    {
        if (!promoIsPercent)
        {
            if (baseAmount == 0m)
            {
                return 0m;
            }

            decimal effectiveDiscountFraction = promoValue / baseAmount;
            decimal discounted = baseAmount * (1m - effectiveDiscountFraction);

            return discounted < 0m ? 0m : discounted;
        }

        decimal discountFraction = promoValue / Constants.PercentScale;
        return baseAmount * (1m - discountFraction);
    }

    private decimal ApplySubscriptionDiscount(decimal baseAmount)
    {
        decimal discountFraction = Constants.SubscriptionDiscountPercent / Constants.PercentScale;
        return baseAmount * (1m - discountFraction);
    }

    private decimal CalculateServiceCommission(decimal baseAmountAfterDiscounts, bool isAirportTrip)
    {
        if (!isAirportTrip)
        {
            return baseAmountAfterDiscounts * (Constants.ServiceCommissionPercent / Constants.PercentScale);
        }

        decimal airportCommissionPercent = GetRandomAirportCommissionPercent();
        return baseAmountAfterDiscounts * (airportCommissionPercent / Constants.PercentScale);
    }

    private static decimal GetRandomAirportCommissionPercent()
    {
        int percent = Random.Shared.Next(Constants.AirportCommissionPercentMin, Constants.AirportCommissionPercentMax + 1);
        return percent;
    }

    private decimal CalculateTariffFee(int tariffChoice)
    {
        if (tariffChoice == Constants.TariffPickupToBuilding)
        {
            if (DistanceKm > Constants.DoorPickupFreeDistanceThresholdKm)
            {
                return 0m;
            }

            return Constants.DoorPickupFixedFee;
        }

        if (tariffChoice == Constants.TariffEconomRoute)
        {
            return PickupFee * Constants.EconomRouteStartFeeCoefficient + Constants.EconomRouteAdditionalFeePerKm * DistanceKm;
        }

        if (tariffChoice == Constants.TariffPremiumElectricCar)
        {
            if (DistanceKm <= Constants.PremiumElectricCarMinDistanceKmExclusive)
            {
                return 0m;
            }

            return Constants.PremiumElectricCarBaseFee + Constants.PremiumElectricCarAdditionalFeePerKm * DistanceKm;
        }

        return 0m;
    }

    private static decimal CalculateIdleFee(int tariffChoice, decimal idleMinutes)
    {
        if (tariffChoice != Constants.TariffIdleTime)
        {
            return 0m;
        }

        return Constants.IdleFeePerMinute * idleMinutes;
    }
}