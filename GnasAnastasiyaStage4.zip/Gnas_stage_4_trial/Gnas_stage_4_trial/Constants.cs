﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gnas_stage_4_trial;

public struct Constants
{
    public const string MoneyFormat = "0.00";
    public const decimal PercentScale = 100m;

    public const decimal MinimumBaseAfterDiscountFactor = 0.70m;

    public const decimal DistanceDiscountFromKmInclusive = 10m;
    public const decimal DistanceDiscountToKmExclusive = 30m;
    public const decimal DistanceDiscountPercentLow = 5m;
    public const decimal DistanceDiscountPercentHigh = 10m;

    public const decimal SubscriptionDiscountPercent = 7m;

    public const int TariffPickupToBuilding = 1;
    public const int TariffEconomRoute = 2;
    public const int TariffIdleTime = 3;
    public const int TariffPremiumElectricCar = 4;

    public const decimal DoorPickupFixedFee = 50m;
    public const decimal DoorPickupFreeDistanceThresholdKm = 20m;

    public const decimal EconomRouteStartFeeCoefficient = 1m;
    public const decimal EconomRouteAdditionalFeePerKm = 1.5m;

    public const decimal IdleFeePerMinute = 0.3m;

    public const decimal PremiumElectricCarBaseFee = 30m;
    public const decimal PremiumElectricCarAdditionalFeePerKm = 0.8m;
    public const decimal PremiumElectricCarMinDistanceKmExclusive = 5m;

    public const decimal ServiceCommissionPercent = 15m;

    public const int AirportCommissionPercentMin = 10;
    public const int AirportCommissionPercentMax = 25;


}

