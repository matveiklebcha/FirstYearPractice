﻿namespace ConsoleApp4;

using System.Globalization;
using System.IO;

internal static class Program
{
    private const int DiscountDayThreshold = 7;
    private const double DiscountRate = 0.05;


    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        try
        {
            Run();
        }
        catch (Exception exception)
        {
            Console.WriteLine();
            Console.WriteLine($"Ошибка программы: {exception.Message}");
            Console.WriteLine("Нажмите Enter для выхода.");
            Console.ReadLine();
        }
    }


    private static void Run()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("1 - Посчитать стоимость аренды авто");
            Console.WriteLine("2 - Выход");
            ShowPrompt(PromptType.MenuChoice);

            string menuChoice = Console.ReadLine()?.Trim() ?? string.Empty;


            if (menuChoice.Length == 0)
            {
                continue;
            }

            switch (menuChoice)
            {
                case "1":
                    CalculateAndShowRentalCostWithIndependentDiscounts();
                    break;
                case "2":
                    Console.WriteLine("Программа завершена.");
                    return;
                default:
                    ShowError(ErrorType.InvalidMenuChoice);
                    break;
            }
        }
    }

    // Организует полный цикл расчёта стоимости аренды: считывает дни, ставку, прошлые аренды,

    private static void CalculateAndShowRentalCostWithIndependentDiscounts()
    {
        Console.WriteLine();
        Console.WriteLine("--- Расчёт стоимости аренды ---");

        int rentalDays = ReadPositiveInteger();
        double dailyRate = ReadPositiveNumber();
        int previousRentalCount = ReadNonNegativeInteger();

        // этап 4
        string clientId = ReadClientId();

        ShowPrompt(PromptType.CorporatePromoCode);
        string promoCode = Console.ReadLine() ?? string.Empty;
        double corporatePromoDiscountRate = GetDiscountRateByCode(promoCode);

        double totalAmount = CalculateTotalAmount(
            rentalDays,
            dailyRate,
            previousRentalCount,
            corporatePromoDiscountRate);

        // этап 4
        totalAmount = ApplyStageFourDiscounts(
            rentalDays,
            dailyRate,
            previousRentalCount,
            promoCode,
            clientId);

        Console.WriteLine();
        Console.WriteLine($"Сумма после скидок: {totalAmount}");


        double finalTotal = RunStageFourDelivery(rentalDays, totalAmount);
        Console.WriteLine();
        Console.WriteLine($"Итого: {finalTotal}");
        Console.ReadKey();
    }

    // В цикле запрашивает у пользователя целое число строго больше 0 (количество дней аренды).
    // При некорректном вводе выводит ошибку и повторяет запрос.
    private static int ReadPositiveInteger()
    {
        int rentalDays;
        while (true)
        {
            ShowPrompt(PromptType.RentalDays);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveInteger(input, out rentalDays))
            {
                break;
            }

            ShowError(ErrorType.InvalidInteger);
        }

        return rentalDays;
    }

    // В цикле запрашивает у пользователя число строго больше 0 (стоимость аренды за день).
    // Поддерживает ввод через запятую или точку.
    private static double ReadPositiveNumber()
    {
        double dailyRate;
        while (true)
        {
            ShowPrompt(PromptType.DailyRate);

            string input = Console.ReadLine() ?? "0";
            if (TryParsePositiveNumber(input, out dailyRate))
            {
                break;
            }

            ShowError(ErrorType.InvalidNumber);
        }

        return dailyRate;
    }

    // В цикле запрашивает у пользователя целое число 0 или больше (количество прошлых аренд).
    private static int ReadNonNegativeInteger()
    {
        int previousRentalCount;
        while (true)
        {
            ShowPrompt(PromptType.PreviousRentalCount);

            string input = Console.ReadLine() ?? "0";
            if (TryParseNonNegativeInteger(input, out previousRentalCount))
            {
                break;
            }

            ShowError(ErrorType.InvalidNonNegativeInteger);
        }

        return previousRentalCount;
    }

    // Пытается преобразовать строку в int. Возвращает true, если значение успешно распарсено
    // и строго больше 0.
    private static bool TryParsePositiveInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value > 0;
    }

    // Пытается преобразовать строку в int. Возвращает true, если значение успешно распарсено
    // и больше или равно 0.
    private static bool TryParseNonNegativeInteger(string input, out int value)
    {
        if (!int.TryParse(input.Trim(), out value))
        {
            return false;
        }

        return value >= 0;
    }

    // Пытается преобразовать строку в double. 
    private static bool TryParsePositiveNumber(string input, out double value)
    {
        string normalizedInput = input.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedInput, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            return false;
        }

        return value > 0;
    }





    private static void ShowPrompt(PromptType promptType)
    {
        string prompt = promptType switch
        {
            PromptType.MenuChoice => "Введите номер пункта: ",
            PromptType.RentalDays => "Введите количество дней аренды: ",
            PromptType.DailyRate => "Введите стоимость аренды за 1 день: ",
            PromptType.PreviousRentalCount => "Введите количество прошлых аренд клиента: ",
            PromptType.CorporatePromoCode => "Введите корпоративный промокод (или Enter, если нет): ",
            PromptType.DeliveryMethod => "Введите номер варианта: ",
            PromptType.DistanceKilometers => "Введите расстояние от офиса в километрах: ",
            PromptType.IsPremiumCar => "Автомобиль премиум-класса? (1 - да, 0 - нет): ",
            _ => GetStageFourPromptText(promptType),
        };

        Console.Write(prompt);
    }

    // Выводит текст сообщения об ошибке в зависимости от типа 
    private static void ShowError(ErrorType errorType)
    {
        string message = errorType switch
        {
            ErrorType.InvalidMenuChoice => "Нет такого пункта меню!",
            ErrorType.InvalidInteger => "Ошибка! Нужно ввести целое число больше 0",
            ErrorType.InvalidNumber => "Ошибка! Нужно ввести число больше 0",
            ErrorType.InvalidNonNegativeInteger => "Ошибка! Нужно ввести целое число 0 или больше",
            ErrorType.InvalidDeliveryMethod => "Ошибка! Нужно ввести 1, 2 или 3",
            ErrorType.InvalidDistance => "Ошибка! Нужно ввести число 0 или больше",
            ErrorType.InvalidPremiumChoice => "Ошибка! Нужно ввести 1 или 0",
            _ => GetStageFourErrorText(errorType),
        };

        Console.WriteLine(message);
    }

    private enum PromptType
    {
        MenuChoice,
        RentalDays,
        DailyRate,
        PreviousRentalCount,
        CorporatePromoCode,
        DeliveryMethod,
        DistanceKilometers,
        IsPremiumCar,
        ClientId,
    }

    private enum ErrorType
    {
        InvalidMenuChoice,
        InvalidInteger,
        InvalidNumber,
        InvalidNonNegativeInteger,
        InvalidDeliveryMethod,
        InvalidDistance,
        InvalidPremiumChoice,
        InvalidClientId,
        InvalidTowTruckDelivery,
        InvalidDeliveryMethodStageFour,
    }

    private enum DeliveryMethod
    {
        City = 1,
        OutOfCity = 2,
        ParkingPickup = 3,
    }

    // В цикле запрашивает расстояние от офиса в километрах (число 0 или больше).
    private static double ReadDistanceKilometers()
    {
        double distanceKilometers;
        while (true)
        {
            ShowPrompt(PromptType.DistanceKilometers);

            string input = Console.ReadLine() ?? "0";
            if (TryParseNonNegativeNumber(input, out distanceKilometers))
            {
                break;
            }

            ShowError(ErrorType.InvalidDistance);
        }

        return distanceKilometers;
    }

    // В цикле запрашивает, является ли автомобиль премиум-класса.

    private static bool ReadIsPremiumCar()
    {
        while (true)
        {
            ShowPrompt(PromptType.IsPremiumCar);

            string input = Console.ReadLine() ?? "0";
            if (input.Trim() == "1")
            {
                return true;
            }

            if (input.Trim() == "0")
            {
                return false;
            }

            ShowError(ErrorType.InvalidPremiumChoice);
        }
    }



    //Нормализует ввод (заменяет запятую на точку).
    // Возвращает true, если значение больше или равно 0.
    private static bool TryParseNonNegativeNumber(string input, out double value)
    {
        string normalizedInput = input.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedInput, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            return false;
        }

        return value >= 0;
    }



    // Рассчитывает страховой сбор: для премиум-авто 
    private static double CalculateInsuranceFee(double amountAfterDiscounts, bool isPremiumCar)
    {
        if (isPremiumCar)
        {
            double riskProfileRate = 0.05 + Random.Shared.NextDouble() * 0.10;
            return amountAfterDiscounts * riskProfileRate;
        }

        return amountAfterDiscounts * 0.08;
    }


    private enum StageFourDeliveryMethod
    {
        City = 1,
        OutOfCity = 2,
        ParkingPickup = 3,
        TowTruckToAirport = 4,
    }

    private const double StageFourMaxTotalDiscountRate = 0.35;
    private const int StageFourTowTruckMinRentalDays = 3;
    private const double StageFourTowTruckBaseFee = 25;
    private const double StageFourTowTruckRatePerKm = 3;

    private static readonly string StageFourPromoCodesFilePath = Path.Combine(
        AppContext.BaseDirectory,
        "corporate_promo_codes.txt");

    private static readonly string StageFourUsedPromoCodesFilePath = Path.Combine(
        AppContext.BaseDirectory,
        "corporate_promo_used.txt");

    // Возвращает текст подсказки для типов, добавленных на этапе 4 (например, ClientId).
    // Для неизвестных типов возвращает пустую строку.
    private static string GetStageFourPromptText(PromptType promptType)
    {
        return promptType switch
        {
            PromptType.ClientId => "Введите идентификатор клиента: ",
            _ => string.Empty,
        };
    }

    // Возвращает текст ошибки для типов этапа 4 
    private static string GetStageFourErrorText(ErrorType errorType)
    {
        return errorType switch
        {
            ErrorType.InvalidClientId => "Ошибка! Идентификатор клиента не может быть пустым",
            ErrorType.InvalidTowTruckDelivery => "Ошибка! Доставка эвакуатором доступна только при аренде более 3 дней",
            ErrorType.InvalidDeliveryMethodStageFour => "Ошибка! Нужно ввести 1, 2, 3 или 4",
            _ => "Неизвестная ошибка",
        };
    }

    // Координирует применение скидок этапа 4: получает валидную ставку корпоративной скидки

    private static double ApplyStageFourDiscounts(
        int rentalDays,
        double dailyRate,
        int previousRentalCount,
        string promoCode,
        string clientId)
    {
        double corporatePromoDiscountRate = GetStageFourValidDiscountRate(promoCode, clientId);

        return CalculateStageFourTotalAmount(
            rentalDays,
            dailyRate,
            previousRentalCount,
            corporatePromoDiscountRate);
    }

    // В цикле запрашивает идентификатор клиента. Пустая или состоящая только из пробеловстрока не принимается.
    private static string ReadClientId()
    {
        while (true)
        {
            ShowPrompt(PromptType.ClientId);

            string input = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(input))
            {
                return input.Trim();
            }

            ShowError(ErrorType.InvalidClientId);
        }
    }

    // Определяет ставку скидки по промокоду
    private static double GetStageFourValidDiscountRate(string promoCode, string clientId)
    {
        if (string.IsNullOrWhiteSpace(promoCode))
        {
            return 0;
        }

        if (!File.Exists(StageFourPromoCodesFilePath))
        {
            return 0;
        }

        foreach (string line in File.ReadAllLines(StageFourPromoCodesFilePath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith('#'))
            {
                continue;
            }

            string[] codeParts = line.Split('=', 2, StringSplitOptions.TrimEntries);
            if (codeParts.Length != 2)
            {
                continue;
            }

            if (!codeParts[0].Equals(promoCode, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            string[] valueParts = codeParts[1].Split(':', StringSplitOptions.TrimEntries);
            if (!double.TryParse(valueParts[0], out double percent) || percent < 0)
            {
                return 0;
            }

            if (valueParts.Length == 1)
            {
                return percent / 100;
            }

            string boundClientId = valueParts[1];
            if (!boundClientId.Equals(clientId, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Ошибка! Промокод привязан к другому клиенту.");
                return 0;
            }

            if (IsStageFourPromoCodeAlreadyUsed(clientId, promoCode))
            {
                Console.WriteLine("Ошибка! Промокод уже использован этим клиентом.");
                return 0;
            }

            MarkStageFourPromoCodeAsUsed(clientId, promoCode);
            return percent / 100;
        }

        return GetDiscountRateByCode(promoCode);
    }

    // Проверяет файл corporate_promo_used.txt на наличие записи clientId:promoCode.
    // Возвращает true, если такая запись есть (промокод уже использован).
    private static bool IsStageFourPromoCodeAlreadyUsed(string clientId, string promoCode)
    {
        if (!File.Exists(StageFourUsedPromoCodesFilePath))
        {
            return false;
        }

        string record = $"{clientId}:{promoCode}";

        foreach (string line in File.ReadAllLines(StageFourUsedPromoCodesFilePath))
        {
            if (line.Equals(record, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    // Дописывает запись clientId:promoCode в файл corporate_promo_used.txt, чтобы предотвратить
    // повторное использование промокода этим клиентом.
    private static void MarkStageFourPromoCodeAsUsed(string clientId, string promoCode)
    {
        string record = $"{clientId}:{promoCode}";
        File.AppendAllLines(StageFourUsedPromoCodesFilePath, new[] { record });
    }

    // Рассчитывает итоговую сумму с учётом всех скидок
    private static double CalculateStageFourTotalAmount(
        int rentalDays,
        double dailyRate,
        int previousRentalCount,
        double corporatePromoDiscountRate)
    {
        double baseAmount = rentalDays * dailyRate;

        double durationDiscountRate = GetDiscountRate(rentalDays);
        double regularRenterDiscountRate = GetDiscountRate(previousRentalCount);

        double maxPersonalDiscountRate = Math.Max(durationDiscountRate, regularRenterDiscountRate);
        double totalDiscountRate = maxPersonalDiscountRate + corporatePromoDiscountRate;

        if (totalDiscountRate > StageFourMaxTotalDiscountRate)
        {
            totalDiscountRate = StageFourMaxTotalDiscountRate;
        }

        return baseAmount * (1 - totalDiscountRate);
    }

    // Организует расчёт доставки и страхового сбора: спрашивает способ доставки, при необходимости

    private static double RunStageFourDelivery(int rentalDays, double amountAfterDiscounts)
    {
        Console.WriteLine();
        Console.WriteLine("--- Доставка и страховой сбор ---");

        StageFourDeliveryMethod deliveryMethod = ReadStageFourDeliveryMethod(rentalDays);
        double distanceKilometers = 0;

        if (deliveryMethod == StageFourDeliveryMethod.OutOfCity
            || deliveryMethod == StageFourDeliveryMethod.TowTruckToAirport)
        {
            distanceKilometers = ReadDistanceKilometers();
        }

        bool isPremiumCar = ReadIsPremiumCar();

        double deliveryFee = CalculateStageFourDeliveryFee(deliveryMethod, rentalDays, distanceKilometers);
        double insuranceFee = CalculateInsuranceFee(amountAfterDiscounts, isPremiumCar);
        double finalTotal = (amountAfterDiscounts + insuranceFee) + deliveryFee;

        Console.WriteLine();
        Console.WriteLine($"Доставка: {deliveryFee}");
        Console.WriteLine($"Страховой сбор: {insuranceFee}");

        return finalTotal;
    }

    // Выводит меню способов доставки (1–4) и считывает выбор. 
    private static StageFourDeliveryMethod ReadStageFourDeliveryMethod(int rentalDays)
    {
        StageFourDeliveryMethod deliveryMethod;
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("1 - Доставка в город");
            Console.WriteLine("2 - Доставка за город");
            Console.WriteLine("3 - Самовывоз с парковки");
            Console.WriteLine("4 - Доставка эвакуатором в аэропорт");
            ShowPrompt(PromptType.DeliveryMethod);

            string input = Console.ReadLine() ?? "0";
            if (TryParseStageFourDeliveryMethod(input, rentalDays, out deliveryMethod))
            {
                break;
            }

            ShowError(ErrorType.InvalidDeliveryMethodStageFour);
        }

        return deliveryMethod;
    }

    // Парсит выбор метода доставки (1–4). Дополнительно проверяет, что эвакуатор (4) доступен
    // только при rentalDays > 3. При ошибке возвращает false и устанавливает deliveryMethod = default.
    private static bool TryParseStageFourDeliveryMethod(string input, int rentalDays, out StageFourDeliveryMethod deliveryMethod)
    {
        if (!int.TryParse(input.Trim(), out int value))
        {
            deliveryMethod = default;
            return false;
        }

        if (value < 1 || value > 4)
        {
            deliveryMethod = default;
            return false;
        }

        deliveryMethod = (StageFourDeliveryMethod)value;

        if (deliveryMethod == StageFourDeliveryMethod.TowTruckToAirport && !(rentalDays > StageFourTowTruckMinRentalDays))
        {
            deliveryMethod = default;
            ShowError(ErrorType.InvalidTowTruckDelivery);
            return false;
        }

        return true;
    }

    private static double CalculateStageFourDeliveryFee(
        StageFourDeliveryMethod deliveryMethod,
        int rentalDays,
        double distanceKilometers)
    {
        switch (deliveryMethod)
        {
            case StageFourDeliveryMethod.City:
                if (rentalDays > 14)
                {
                    return 0;
                }

                return 20;
            case StageFourDeliveryMethod.OutOfCity:
                return 15 + 2 * distanceKilometers;
            case StageFourDeliveryMethod.ParkingPickup:
                return 0;
            case StageFourDeliveryMethod.TowTruckToAirport:
                return StageFourTowTruckBaseFee + StageFourTowTruckRatePerKm * distanceKilometers;
            default:
                return 0;
        }
    }

    // Вспомогательные методы для расчёта скидок
    private static double CalculateTotalAmount(
        int rentalDays,
        double dailyRate,
        int previousRentalCount,
        double corporatePromoDiscountRate)
    {
        const double MaxTotalDiscountRate = 0.35;
        double baseAmount = rentalDays * dailyRate;

        double durationDiscountRate = GetDiscountRate(rentalDays);
        double regularRenterDiscountRate = GetDiscountRate(previousRentalCount);

        double maxPersonalDiscountRate = Math.Max(durationDiscountRate, regularRenterDiscountRate);
        double totalDiscountRate = maxPersonalDiscountRate + corporatePromoDiscountRate;

        if (totalDiscountRate > MaxTotalDiscountRate)
        {
            totalDiscountRate = MaxTotalDiscountRate;
        }

        return baseAmount * (1 - totalDiscountRate);
    }

    private static double GetDiscountRate(int rentalDays)
    {
        if (rentalDays >= 14)
            return 0.20;
        if (rentalDays >= 7)
            return 0.10;
        if (rentalDays >= 3)
            return 0.05;
        return 0;
    }

    private static double GetDiscountRateByCode(string promoCode)
    {
        if (string.IsNullOrWhiteSpace(promoCode))
            return 0;
        return 0;
    }
}