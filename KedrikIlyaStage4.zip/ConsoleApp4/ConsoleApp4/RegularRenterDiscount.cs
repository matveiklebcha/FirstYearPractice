namespace ConsoleApp4;

internal static class RegularRenterDiscount
{
    private const int FivePercentFromRentals = 3;
    private const int TenPercentFromRentals = 6;
    private const double FivePercentRate = 0.05;
    private const double TenPercentRate = 0.10;

    public static double GetDiscountRate(int previousRentalCount)
    {
        if (previousRentalCount >= TenPercentFromRentals)
        {
            return TenPercentRate;
        }

        if (previousRentalCount >= FivePercentFromRentals)
        {
            return FivePercentRate;
        }

        return 0;
    }
}
