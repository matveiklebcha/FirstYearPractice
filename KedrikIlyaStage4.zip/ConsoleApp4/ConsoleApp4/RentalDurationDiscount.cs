namespace ConsoleApp4;

internal static class RentalDurationDiscount
{
    private const int FivePercentFromDays = 7;
    private const int FifteenPercentFromDays = 30;
    private const double FivePercentRate = 0.05;
    private const double FifteenPercentRate = 0.15;

    public static double GetDiscountRate(int rentalDays)
    {
        if (rentalDays >= FifteenPercentFromDays)
        {
            return FifteenPercentRate;
        }

        if (rentalDays >= FivePercentFromDays)
        {
            return FivePercentRate;
        }

        return 0;
    }
}
