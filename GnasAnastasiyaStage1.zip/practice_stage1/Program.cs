﻿// See https://aka.ms/new-console-template for more information
using System.Globalization;

namespace TaxiFareStage1
{
    internal class Program
    {
        private const decimal LongDistanceThresholdKm = 10m;
        private const decimal LongDistanceDiscountPercent = 5m;
        private const decimal PercentScale = 100m;
        private const string MoneyFormat = "0.00";

        public struct TaxiTrip
        {
            public decimal DistanceKm { get; }
            public decimal RatePerKm { get; }
            public decimal PickupFee { get; }

            public TaxiTrip(decimal distanceKm, decimal ratePerKm, decimal pickupFee)
            {
                DistanceKm = distanceKm;
                RatePerKm = ratePerKm;
                PickupFee = pickupFee;
            }
        }

        public static void Main(string[] args)
        {
            Console.Write("Расстояние поездки (км): ");
            decimal distanceKm = ReadPositiveDecimal();
            while (distanceKm <= 0m)
            {
                Console.WriteLine("Ошибка: введите число больше 0.");
                Console.Write("Расстояние поездки (км): ");
                distanceKm = ReadPositiveDecimal();
            }

            Console.Write("Базовый тариф за километр: ");
            decimal ratePerKm = ReadPositiveDecimal();
            while (ratePerKm <= 0m)
            {
                Console.WriteLine("Ошибка: введите число больше 0.");
                Console.Write("Базовый тариф за километр: ");
                ratePerKm = ReadPositiveDecimal();
            }

            Console.Write("Стартовая плата за подачу: ");
            decimal pickupFee = ReadPositiveDecimal();
            while (pickupFee <= 0m)
            {
                Console.WriteLine("Ошибка: введите число больше 0.");
                Console.Write("Стартовая плата за подачу: ");
                pickupFee = ReadPositiveDecimal();
            }

            TaxiTrip trip = new TaxiTrip(distanceKm, ratePerKm, pickupFee);

            decimal totalPrice = CalculateTotalPrice(trip);

            Console.WriteLine($"Итого: {totalPrice.ToString(MoneyFormat, CultureInfo.InvariantCulture)}");
        }

        private static decimal CalculateTotalPrice(TaxiTrip trip)
        {
            decimal distanceCost = trip.DistanceKm * trip.RatePerKm;

            if (trip.DistanceKm > LongDistanceThresholdKm)
            {
                decimal discountAmount = distanceCost * LongDistanceDiscountPercent / PercentScale;
                distanceCost -= discountAmount;
            }

            return trip.PickupFee + distanceCost;
        }

        private static decimal ReadPositiveDecimal()
        {
            string? input = Console.ReadLine();
            if (TryParsePositiveDecimal(input, out decimal value))
            {
                return value;
            }

            return 0m;
        }

        private static bool TryParsePositiveDecimal(string? input, out decimal value)
        {
            value = 0m;
            if (string.IsNullOrWhiteSpace(input)) return false;

            string normalized = input.Trim().Replace(',', '.');

            bool success = decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value);

            return success && value > 0m;
        }
    }
}

