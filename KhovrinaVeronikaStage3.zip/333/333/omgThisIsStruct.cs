﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace intership_LOL_XD
{
    public struct Ticket(string category, double price, bool isElectronic)
    {
        public string Category = category;
        public double Price = price;
        public bool isElectronic = isElectronic;
    }

}
