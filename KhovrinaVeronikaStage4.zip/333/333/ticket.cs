﻿

namespace intership_LOL_XD
{
    public struct Ticket(string category, double price, bool isElectronic)
    {
        public string Category = category;
        public double Price = price;
        public bool isElectronic = isElectronic;
    }
   
}
