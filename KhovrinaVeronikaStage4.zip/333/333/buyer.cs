﻿

namespace intership_LOL_XD
{
    public struct Buyer(int id, string name, bool isFanClubMember)
    {
        public int Id { get; set; } = id;
        public string Name { get; set; } = name;
        public bool IsFanClubMember { get; set; } = isFanClubMember;
        public List<string> UsedPromoCodes { get; set; } = new List<string>();
    }
}
