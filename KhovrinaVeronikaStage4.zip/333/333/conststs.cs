﻿

namespace intership_LOL_XD
{
    public struct Constants
    {
        public const double DiscountTier1Threshold = 3;
        public const double DiscountTier2Threshold = 10;
        public const double DiscountTier1Rate = 0.05;
        public const double DiscountTier2Rate = 0.12;
        public const double FanClubDiscountRate = 0.08;
        public const double MaxTotalPercentDiscount = 0.25;
        public const double PaymentFeeRate = 0.02;
        public const double ServiceFeePerTicket = 3.0;
        public const int ServiceFeeFreeThreshold = 5;
        public const double VipBaseFee = 10.0;
        public const double VipPerTicketFee = 4.0;

    }

}
