﻿

namespace intership_LOL_XD
{
    internal class Program
    {
        public const string PromoFilePath = "promo.txt";
        public const string BuyersFilePath = "buyers.txt";
        static void Main()
        {
            string[] promoLines = LoadFileLines(PromoFilePath, "Файл промокодов не найден");
            string[] buyerLines = LoadFileLines(BuyersFilePath, "Файл покупателей не найден. Будет создан новый покупатель.");
            Console.WriteLine(AppDomain.CurrentDomain.BaseDirectory);
            Console.WriteLine("Расчёт стоимости билетов на концерт\n");
            Buyer currentBuyer = FindOrCreateBuyer(buyerLines);
            int ticketCount = ReadPositiveInteger("Введите количество билетов: ");
            List<Ticket> tickets = ReadTickets(ticketCount);
            double promoDiscount = ReadPromoCode(promoLines, ref currentBuyer);
            bool isForeignCard = ReadYesNo("Оплата иностранной картой? (да/нет): ");
            bool needsDelivery = AskForDeliveryIfNeeded(tickets);
            double baseSum = CalculateBaseSum(tickets);
            double finalSum = CalculateTotalPrice(baseSum, ticketCount, currentBuyer, promoDiscount, tickets, isForeignCard, needsDelivery);
            Console.WriteLine($"\nИтоговая сумма к оплате для {currentBuyer.Name} (ID: {currentBuyer.Id}): {finalSum:F2} у.е.");
            SaveBuyerToFile(currentBuyer, BuyersFilePath);
        }
        static Buyer FindOrCreateBuyer(string[] buyerLines)
        {
            int inputId = ReadPositiveInteger("Введите ваш числовой ID покупателя для входа: ");
            Buyer? foundBuyer = TryParseExistingBuyer(buyerLines, inputId);
            if (foundBuyer != null)
            {
                Console.WriteLine($"Успешный вход! Добро пожаловать, {foundBuyer.Value.Name}. Подписка фан-клуба: {(foundBuyer.Value.IsFanClubMember ? "Есть" : "Нет")}");
                return foundBuyer.Value;
            }
            return RegisterNewBuyer(inputId);
        }
        static Buyer? TryParseExistingBuyer(string[] buyerLines, int inputId)
        {
            foreach (string line in buyerLines)
            {
                Buyer? buyer = ParseBuyerFromLine(line, inputId);
                if (buyer != null)
                    return buyer;
            }
            return null;
        }
        static Buyer? ParseBuyerFromLine(string line, int inputId)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;
            string[] parts = line.Split(';');
            if (parts.Length < 3)
                return null;
            if (!int.TryParse(parts[0].Trim(), out int fileId) || fileId != inputId)
                return null;
            string name = parts[1].Trim();
            bool isActive = parts[2].Trim().Equals("да", StringComparison.OrdinalIgnoreCase);
            Buyer buyer = new Buyer(inputId, name, isActive);
            if (parts.Length >= 4 && !string.IsNullOrWhiteSpace(parts[3]))
            {
                AddPromoCodes(buyer, parts[3]);
            }
            return buyer;
        }
        static void AddPromoCodes(Buyer buyer, string codesSegment)
        {
            if (string.IsNullOrWhiteSpace(codesSegment))
                return;
            string[] codes = codesSegment.Split(',', StringSplitOptions.RemoveEmptyEntries);
            foreach (string code in codes)
            {
                buyer.UsedPromoCodes.Add(code.Trim().ToUpper());
            }
        }
        static Buyer RegisterNewBuyer(int id)
        {
            Console.WriteLine("ID не найден в базе данных. Пройдите быструю регистрацию.");
            string name = ReadNonEmptyString("Введите ваше имя: ");
            bool isFan = ReadYesNo("Вы являетесь подписчиком фан-клуба? (да/нет): ");
            return new Buyer(id, name, isFan);
        }

        static void SaveBuyerToFile(Buyer buyer, string filePath)
        {
            List<string> lines = File.Exists(filePath)
                ? File.ReadAllLines(filePath).ToList()
                : new List<string>();
            bool isUpdated = false;
            for (int i = 0; i < lines.Count; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line))
                    continue;
                string[] parts = line.Split(';');
                if (parts.Length < 1)
                    continue; 
                if (!int.TryParse(parts[0].Trim(), out int fileId))
                    continue; 
                if (fileId != buyer.Id)
                    continue; 
                lines[i] = SerializeBuyer(buyer);
                isUpdated = true;
                break;
            }
            if (!isUpdated)
                lines.Add(SerializeBuyer(buyer));
            File.WriteAllLines(filePath, lines);
            Console.WriteLine("Данные покупателя успешно сохранены в базе.");
        }

        static string SerializeBuyer(Buyer buyer)
        {
            string fanString = buyer.IsFanClubMember ? "да" : "нет";
            string codesString = string.Join(",", buyer.UsedPromoCodes);
            return $"{buyer.Id};{buyer.Name};{fanString};{codesString}";
        }
        static bool IsPromoAlreadyUsedByBuyer(Buyer buyer, string promoCode)
        {
            return buyer.UsedPromoCodes.Contains(promoCode.ToUpper());
        }
        static double ReadPromoCode(string[] promoLines, ref Buyer buyer)
        {
            while (true)
            {
                Console.Write("Введите промокод (или оставьте пустым): ");
                string? input = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(input)) 
                    return 0;
                if (IsPromoAlreadyUsedByBuyer(buyer, input))
                {
                    Console.WriteLine($"Ошибка: Вы ({buyer.Name}) уже активировали этот промокод ранее! Попробуйте другой.");
                    continue;
                }
                double discount = ProcessPromoLines(promoLines, input, buyer);
                if (discount >= 0) return discount;
            }
        }
        static double ProcessPromoLines(string[] promoLines, string inputCode, Buyer buyer)
        {
            foreach (string line in promoLines)
            {
                double? discount = TryParsePromoLine(line, inputCode, buyer);
                if (discount.HasValue)
                    return discount.Value;
            }

            Console.WriteLine("Промокод не найден. Попробуйте ещё раз.");
            return -1;
        }

        static double? TryParsePromoLine(string line, string inputCode, Buyer buyer)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;
            string[] parts = line.Split(';');
            if (parts.Length < 2)
                return null;
            string fileCode = parts[0].Trim();
            if (!string.Equals(fileCode, inputCode, StringComparison.OrdinalIgnoreCase))
                return null; 
            double discountValue = double.Parse(parts[1].Trim());
            if (parts.Length >= 3 && !IsBuyerAllowedForPromo(parts[2], buyer))
            {
                Console.WriteLine("Ошибка: Данный промокод предназначен только для определенных клиентов! Попробуйте другой.");
                return -1;
            }
            Console.WriteLine($"Промокод принят! Скидка {discountValue} у.е.");
            buyer.UsedPromoCodes.Add(fileCode.ToUpper());
            return discountValue;
        }
        static bool IsBuyerAllowedForPromo(string allowedIdsPart, Buyer buyer)
        {
            foreach (var id in allowedIdsPart.Split(','))
            {
                string cleanId = id.Trim();
                if (string.Equals(cleanId, buyer.Name, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
                if (int.TryParse(cleanId, out int allowedId) && allowedId == buyer.Id)
                {
                    return true;
                }
            }
            return false;
        }
        static List<Ticket> ReadTickets(int count)
        {
            var tickets = new List<Ticket>(count);
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"\nБилет #{i + 1}:");
                tickets.Add(ReadTicket());
            }
            return tickets;
        }
        static Ticket ReadTicket()
        {
            string category = ReadNonEmptyString("Введите категорию места (портер, танцпол, vip и т.д.): ");
            double price = ReadPositiveDouble("Введите цену билета: ");
            bool isElectronic = ReadYesNo("Билет электронный?(да/нет)");
            return new Ticket(category, price, isElectronic);
        }
        static bool AskForDeliveryIfNeeded(List<Ticket> tickets)
        {
            if (tickets.Count <= 1)
                return false;
            if (!tickets.Any(t => !t.isElectronic))
                return false;
            return ReadYesNo("Нужна доставка билетов курьером? (да/нет): ");
        }
        static string[] LoadFileLines(string filePath, string errorMessage)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine(errorMessage);
                return Array.Empty<string>();
            }
            return File.ReadAllLines(filePath);
        }
        static string ReadNonEmptyString(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(input)) 
                    return input;
                Console.WriteLine("Ошибка: Категория не может быть пустой.");
            }
        }
        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveInteger(input, out int value)) 
                    return value;
                Console.WriteLine("Ошибка: Введите положительное целое число.");
            }
        }
        static double ReadPositiveDouble(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (TryParsePositiveDouble(input, out double value))
                    return value;
                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }
        static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine()?.Trim().ToLower();
                if (input == "да" || input == "yes" || input == "y" || input == "д")
                    return true;
                if (input == "нет" || input == "no" || input == "n" || input == "н")
                    return false;
                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;
            if (int.TryParse(input, out int parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }

        static bool TryParsePositiveDouble(string input, out double value)
        {
            value = 0;
            if (double.TryParse(input, out double parsed) && parsed > 0)
            {
                value = parsed;
                return true;
            }
            return false;
        }

        static double CalculateBaseSum(List<Ticket> tickets)
        {
            double sum = 0;
            foreach (var t in tickets) sum += t.Price;
            return sum;
        }

        static double CalculateQuantityDiscount(int ticketCount)
        {
            if (ticketCount >= Constants.DiscountTier2Threshold) return Constants.DiscountTier2Rate;
            if (ticketCount >= Constants.DiscountTier1Threshold) return Constants.DiscountTier1Rate;
            return 0;
        }
        static double CalculateCombinedPercentDiscount(int ticketCount, Buyer buyer)
        {
            double quantityDiscount = CalculateQuantityDiscount(ticketCount);
            double fanClubDiscount = buyer.IsFanClubMember ? Constants.FanClubDiscountRate : 0;
            double maxPercentDiscount = Math.Max(quantityDiscount, fanClubDiscount);
            return Math.Min(maxPercentDiscount, Constants.MaxTotalPercentDiscount);
        }
        static double CalculateOptionFee(int ticketCount, List<Ticket> tickets)
        {
            bool hasVip = tickets.Exists(t => t.Category.ToLower() == "vip" || t.Category.ToLower() == "вип");
            bool allElectronic = tickets.TrueForAll(t => t.isElectronic);
            if (hasVip)
            {
                return Constants.ServiceFeePerTicket + Constants.VipBaseFee + Constants.VipPerTicketFee * ticketCount;
            }
            if (allElectronic)
            {
                return 0;
            }
            if (ticketCount > Constants.ServiceFeeFreeThreshold)
                return 0;
            else
                return Constants.ServiceFeePerTicket * ticketCount;
        }
        static double CalculatePaymentFee(double amountAfterDiscount, bool isForeignCard)
        {
            if (!isForeignCard)
            {
                return amountAfterDiscount * Constants.PaymentFeeRate;
            }
            else
            {
                Random random = new Random();
                double rate = 0.02 + random.NextDouble() * (0.06 - 0.02);
                double fee = amountAfterDiscount * rate;
                return Math.Max(fee, 0);
            }
        }
        static double ApplyDeliveryCost(double currentTotal, int ticketCount, bool needsDelivery)
        {
            if (needsDelivery && ticketCount > 1)
            {
                double deliveryCost = 7 + (1 * ticketCount);
                Console.WriteLine($"Плата за курьерскую доставку: {deliveryCost:F2} у.е.");
                return currentTotal + deliveryCost;
            }
            return currentTotal;
        }
        static double CalculateTotalPrice(double basePrice, int ticketCount, Buyer buyer, double promoDiscountAbsolute, List<Ticket> tickets, bool isForeignCard, bool needsDelivery)
        {
            double totalPercentDiscount = CalculateCombinedPercentDiscount(ticketCount, buyer);
            double priceAfterPercent = basePrice * (1 - totalPercentDiscount);

            double priceAfterDiscount = Math.Max(priceAfterPercent - promoDiscountAbsolute, 0);

            double paymentFee = CalculatePaymentFee(priceAfterDiscount, isForeignCard);
            double optionFee = CalculateOptionFee(ticketCount, tickets);

            double total = priceAfterDiscount + paymentFee + optionFee;
            total = ApplyDeliveryCost(total, ticketCount, needsDelivery);

            return total;
        }
    }
}