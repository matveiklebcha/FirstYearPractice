﻿using System;
using System.Collections.Generic;

namespace PracticeProject
{
    internal class Program
    {
        const double discountIfCost = 50;
        const double discount = 0.05;
        const double minValueDouble = 0.01;
        const int minValueInt = 1;

        struct DishList
        {
            public string Name;
            public double Price;
            public int Count;
        }

        static void Main(string[] args)
        {
            int count = GetValidIntegerInput("Сколько блюд вы хотите заказать: ", 1, int.MaxValue);
            List<DishList> dishList = InputOrder(count);
            double totalCost = OrderCost(dishList);
            Console.WriteLine($"Итого: {Discount(totalCost):F2}");
            Console.WriteLine("\nНажмите чтобы выйти");
            Console.ReadKey();
        }

        static List<DishList> InputOrder(int count)
        {
            List<DishList> dishList = [];

            for (int i = 0; i < count; i++)
            {
                DishList dish = new();
                Console.WriteLine($"\nБлюдо #{i + 1}");
                dish.Name = GetValidStringInput("Название: ");
                dish.Price = GetValidDoubleInput("Цена: ", minValueDouble, double.MaxValue);
                dish.Count = GetValidIntegerInput("Количество: ", minValueInt, int.MaxValue);
                dishList.Add(dish);
            }
            return dishList;
        }

        static double DishCost(DishList dish)
        {
            return dish.Price * dish.Count;
        }

        static double OrderCost(List<DishList> dishList)
        {
            double sumComposition = 0;
            for (int i = 0; i < dishList.Count; i++)
            {
                sumComposition += DishCost(dishList[i]);
            }
            return sumComposition;
        }

        static double Discount(double sumComposition)
        {
            if (sumComposition > discountIfCost)
            {
                return sumComposition * (1 - discount);
            }
            return sumComposition;
        }

        static bool IsValidInteger(string input, int minValue, int maxValue, out int value, out string errorMessage)
        {
            value = 0;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(input))
            {
                errorMessage = $"Ошибка: Введите целое число от {minValue} до {maxValue}";
                return false;
            }

            if (!int.TryParse(input.Trim(), out value))
            {
                errorMessage = "Ошибка: Нужно целое число (например: 1, 2, 3)";
                return false;
            }

            if (value < minValue || value > maxValue)
            {
                errorMessage = $"Ошибка: Число должно быть от {minValue} до {maxValue}";
                return false;
            }

            return true;
        }

        static bool IsValidDouble(string input, double minValue, double maxValue, out double value, out string errorMessage)
        {
            value = 0.0;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(input))
            {
                errorMessage = $"Ошибка: Введите число от {minValue:F2} до {maxValue:F2}";
                return false;
            }

            input = input.Trim().Replace('.', ',');

            if (!double.TryParse(input, out value))
            {
                errorMessage = "Ошибка: Нужно число (например: 150, 99.99)";
                return false;
            }

            if (value < minValue || value > maxValue)
            {
                errorMessage = $"Ошибка: Число должно быть от {minValue:F2} до {maxValue:F2}";
                return false;
            }

            return true;
        }

        static bool IsValidString(string input, out string value, out string errorMessage)
        {
            value = string.Empty;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(input))
            {
                errorMessage = "Ошибка: Введите название блюда (например: Борщ)";
                return false;
            }

            value = input.Trim();

            if (string.IsNullOrWhiteSpace(value))
            {
                errorMessage = "Ошибка: Название не может состоять только из пробелов";
                return false;
            }

            return true;
        }

        static int GetValidIntegerInput(string message, int minValue, int maxValue)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine() ?? "";

                if (IsValidInteger(input, minValue, maxValue, out int value, out string errorMessage))
                {
                    return value;
                }

                Console.WriteLine(errorMessage);
                Console.WriteLine("Пожалуйста, попробуйте снова.");
            }
        }

        static double GetValidDoubleInput(string message, double minValue, double maxValue)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine() ?? "";

                if (IsValidDouble(input, minValue, maxValue, out double value, out string errorMessage))
                {
                    return value;
                }

                Console.WriteLine(errorMessage);
                Console.WriteLine("Пожалуйста, попробуйте снова.");
            }
        }

        static string GetValidStringInput(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine() ?? "";

                if (IsValidString(input, out string value, out string errorMessage))
                {
                    return value;
                }

                Console.WriteLine(errorMessage);
                Console.WriteLine("Пожалуйста, попробуйте снова.");
            }
        }
    }
}