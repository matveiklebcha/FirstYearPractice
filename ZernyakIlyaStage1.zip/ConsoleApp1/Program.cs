﻿internal class Program
{
	const decimal MultiplierDiscount = 0.05m;
	struct Ticket
	{
		public string typePlace;
		public decimal price;
	}
	public static readonly Dictionary<string, string> Messages = new Dictionary<string, string>
		{
			{ "EmptyType", "Тип места не может быть пустым!" },
			{ "InvalidPrice", "Цена должна быть положительным числом!" },
			{ "InvalidChoice", "Введите да или нет." }
		};
	private static void Main(string[] args)
	{
		List<Ticket> tickets = CreateListTicket();
		decimal priceTickets = PriceReservation(tickets);
		decimal result = priceTickets;
		Console.WriteLine($"{priceTickets} - Cумма цен всех билетов");
		if (tickets.Count >= 4)
		{
			decimal DiscountPrice = DiscountTickets(priceTickets, MultiplierDiscount);
			result = DiscountPrice;
		}
		PrintTickets(result);
	}
	static bool IsValidString(string str)   
	{
		return !string.IsNullOrEmpty(str);
	}

	static bool TryParsePositiveDecimal(string input, out decimal result)
	{
		if (decimal.TryParse(input, out result) && result > 0)
		{
			return true;
		}
		result = 0;
		return false;
	}
	static void ShowError(string key)
	{
		Console.WriteLine(Messages[key]);
	}
	static Ticket InputSingleTicket()
	{
		string typePlace;
		while (true)
		{
			Console.Write("Введите тип места: ");
			typePlace = Console.ReadLine()?.Trim() ?? "";
			if (IsValidString(typePlace))
			{
				break;
			}
			ShowError("EmptyType");
		}

		decimal price;
		while (true)
		{
			Console.Write("Введите цену билета: ");
			string input = Console.ReadLine() ?? "0";
			if (TryParsePositiveDecimal(input, out price))
			{
				break;
			}
			ShowError("InvalidPrice");
		}

		return new Ticket { typePlace = typePlace, price = price };
	}

	static List<Ticket> CreateListTicket()
	{
		List<Ticket> tickets = new List<Ticket>();

		while (true)
		{
			tickets.Add(InputSingleTicket());
			while (true)
			{
				Console.Write("\nХотите добавить еще один билет? (да/нет): ");
				string choice = Console.ReadLine() ?? "";
				if (choice.ToLower() == "да")
				{
					break;
				}
				if(choice.ToLower() == "нет")
				{
					return tickets;
				}
				ShowError("InvalidChoice");
			}
		}

	}
	static decimal PriceReservation(List<Ticket> tickets)
	{
		decimal summarizePrice = 0;

		foreach (Ticket item in tickets)
		{
			summarizePrice += item.price;
		}
		return summarizePrice;
	}
	static decimal DiscountTickets(decimal summarizePrice, decimal multipleDiscount)
	{
		decimal FinalPrice = summarizePrice - (summarizePrice * multipleDiscount);
		return FinalPrice;
	}
	static void PrintTickets(decimal SummaryPrice)
	{
		Console.WriteLine($"Итого: {SummaryPrice:F2}");
	}
}
