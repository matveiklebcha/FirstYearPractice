﻿using System;

namespace MembershipPriceCalculator
{
    class Program
    {
        private const double DiscountRateThreeToTwelveMonths = 0.05;
        private const double DiscountRateTwelveMonthsAndMore = 0.15;
        private const int DiscountThresholdMonthsLower = 3;
        private const int DiscountThresholdMonthsUpper = 12;
        private const double StudentDiscountRate = 0.10;
        private const double MaxTotalPercentageDiscount = 0.30;
        private const double StandardServiceFeePerMonth = 3.0;
        private const int StandardServiceFreeThresholdMonths = 6;
        private const double PersonalTrainerBaseFee = 10.0;
        private const double PersonalTrainerPerSessionFee = 5.0;
        private const double MedicalFeeRate = 0.05;
        private const double MedicalFeeMinRate = 0.01;
        private const double MedicalFeeMaxRate = 0.15;

        static void Main()
        {
            Console.WriteLine("Расчёт стоимости абонемента в фитнес-клуб\n");

            int membershipMonths = ReadPositiveInteger("Введите срок абонемента в месяцах: ");
            double pricePerMonth = ReadPositiveDecimal("Введите стоимость за месяц: ");
            double referralDiscount = ReadReferralDiscount("Введите скидку по реферальному коду на первый месяц: ");
            bool isStudent = ReadStudentStatus("Есть ли у вас студенческий статус? (да/нет): ");
            bool isProfessionalAthlete = ReadProfessionalAthleteStatus("Являетесь ли вы профессиональным спортсменом? (да/нет): ");

            Console.WriteLine("\nВыберите дополнительную услугу:");
            Console.WriteLine("1 - Стандартное обслуживание");
            Console.WriteLine("2 - Персональный тренер");
            Console.WriteLine("3 - Самостоятельные занятия");
            int serviceType = ReadServiceType("Введите номер услуги (1-3): ");

            int trainerSessions = 0;
            if (serviceType == 2)
            {
                trainerSessions = ReadPositiveIntegerOrZero("Введите количество запланированных занятий с тренером: ");
            }

            double totalPrice = CalculateMembershipPrice(
                membershipMonths,
                pricePerMonth,
                referralDiscount,
                isStudent,
                isProfessionalAthlete,
                serviceType,
                trainerSessions);

            Console.WriteLine($"\nИтого: {totalPrice:F2}");
        }

        static int ReadPositiveInteger(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveInteger(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите целое положительное число.");
            }
        }

        static int ReadPositiveIntegerOrZero(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveIntegerOrZero(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите целое неотрицательное число.");
            }
        }

        static double ReadPositiveDecimal(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParsePositiveDecimal(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите положительное число.");
            }
        }

        static double ReadReferralDiscount(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParseReferralDiscount(input, out double value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите неотрицательное число.");
            }
        }

        static bool ReadStudentStatus(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да")
                {
                    return true;
                }

                if (input == "нет")
                {
                    return false;
                }

                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static bool ReadProfessionalAthleteStatus(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да"  )
                {
                    return true;
                }

                if (input == "нет"  )
                {
                    return false;
                }

                Console.WriteLine("Ошибка: Введите 'да' или 'нет'.");
            }
        }

        static int ReadServiceType(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (TryParseServiceType(input, out int value))
                {
                    return value;
                }

                Console.WriteLine("Ошибка: Введите число от 1 до 3.");
            }
        }

        static bool TryParsePositiveInteger(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveIntegerOrZero(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue >= 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParsePositiveDecimal(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue > 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParseReferralDiscount(string input, out double value)
        {
            value = 0;

            if (double.TryParse(input, out double parsedValue) && parsedValue >= 0)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static bool TryParseServiceType(string input, out int value)
        {
            value = 0;

            if (int.TryParse(input, out int parsedValue) && parsedValue >= 1 && parsedValue <= 3)
            {
                value = parsedValue;
                return true;
            }

            return false;
        }

        static double CalculateMembershipPrice(
            int months,
            double pricePerMonth,
            double referralDiscount,
            bool isStudent,
            bool isProfessionalAthlete,
            int serviceType,
            int trainerSessions)
        {
            double basePrice = months * pricePerMonth;

            double percentageDiscountRate = CalculatePercentageDiscountRate(months, isStudent);
            double priceAfterPercentageDiscount = basePrice * (1 - percentageDiscountRate);

            double priceAfterReferral = ApplyReferralDiscount(priceAfterPercentageDiscount, pricePerMonth, referralDiscount, months);

            double medicalFee = CalculateMedicalFee(priceAfterReferral, isProfessionalAthlete);

            double additionalServiceFee = CalculateAdditionalServiceFee(months, serviceType, trainerSessions);

            return priceAfterReferral + medicalFee + additionalServiceFee;
        }

        static double CalculatePercentageDiscountRate(int months, bool isStudent)
        {
            double discountRate = 0;

            if (months >= DiscountThresholdMonthsLower && months < DiscountThresholdMonthsUpper)
            {
                discountRate += DiscountRateThreeToTwelveMonths;
            }
            else if (months >= DiscountThresholdMonthsUpper)
            {
                discountRate += DiscountRateTwelveMonthsAndMore;
            }

            if (isStudent)
            {
                discountRate += StudentDiscountRate;
            }

            return Math.Min(discountRate, MaxTotalPercentageDiscount);
        }

        static double ApplyReferralDiscount(double priceAfterPercentageDiscount, double pricePerMonth, double referralDiscount, int months)
        {
            if (months >= 1 && referralDiscount > 0)
            {
                double firstMonthPrice = pricePerMonth;
                double discountedFirstMonthPrice = Math.Max(0, firstMonthPrice - referralDiscount);
                return priceAfterPercentageDiscount - (firstMonthPrice - discountedFirstMonthPrice);
            }

            return priceAfterPercentageDiscount;
        }

        static double CalculateAdditionalServiceFee(int months, int serviceType, int trainerSessions)
        {
            switch (serviceType)
            {
                case 1:
                    return CalculateStandardServiceFee(months);
                case 2:
                    return CalculatePersonalTrainerFee(trainerSessions);
                case 3:
                    return 0;
                default:
                    return 0;
            }
        }

        static double CalculateStandardServiceFee(int months)
        {
            if (months >= StandardServiceFreeThresholdMonths)
            {
                return 0;
            }

            return months * StandardServiceFeePerMonth;
        }

        static double CalculatePersonalTrainerFee(int trainerSessions)
        {
            return PersonalTrainerBaseFee + (trainerSessions * PersonalTrainerPerSessionFee);
        }

        static double CalculateMedicalFee(double priceAfterDiscounts, bool isProfessionalAthlete)
        {
            if (isProfessionalAthlete)
            {
                Random random = new Random();
                double medicalCertificateValidity = random.NextDouble();
                double adjustedRate = MedicalFeeMinRate + (MedicalFeeMaxRate - MedicalFeeMinRate) * (1 - medicalCertificateValidity);

                Console.WriteLine($"\n Результат проверки медицинской справки: {medicalCertificateValidity:F2} ({medicalCertificateValidity * 100:F0}%)");
                Console.WriteLine($" Ставка медицинского сбора: {adjustedRate:P2}");

                return priceAfterDiscounts * adjustedRate;
            }
            else
            { 
                return priceAfterDiscounts * MedicalFeeRate;
            }
        }
    }
}
